"""
API Routes
FastAPI endpoints for the trading platform
"""
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException, Query
from fastapi.responses import JSONResponse
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from pydantic import BaseModel
import logging
import json

from app.schemas.schemas import (
    MarketDataResponse,
    WatchlistCreate,
    WatchlistResponse,
    BacktestParameters,
    BacktestResultResponse,
    StrategyConfigCreate,
    StrategyConfigResponse,
    SignalResponse,
    HealthCheckResponse,
    IndicatorSet,
)
from app.services.indicators import TechnicalIndicators
from app.services.backtester import Backtester, BacktestConfig
from app.services.risk_manager import RiskManager, RiskLimits
from app.services.websocket_manager import ws_manager
from app.services.data_service import market_data_service
from app.strategies.base import StrategyRegistry
from app.core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter()

# Global instances
risk_manager = RiskManager(
    initial_capital=settings.DEFAULT_INITIAL_CAPITAL,
    limits=RiskLimits()
)
indicators = TechnicalIndicators()


# Health check
@router.get("/health", response_model=HealthCheckResponse)
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "database": "connected",
        "websocket": "active" if ws_manager.is_connected else "inactive",
    }


# Market Data endpoints
@router.get("/market/prices/{symbol}")
async def get_market_price(symbol: str):
    """Get latest market price for a symbol"""
    try:
        price_data = await market_data_service.get_latest_price(symbol)
        if price_data is None:
            raise HTTPException(status_code=404, detail=f"Symbol {symbol} not found")
        return price_data
    except Exception as e:
        logger.error(f"Error getting market price: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/market/prices")
async def get_multiple_prices(symbols: str = Query(..., description="Comma-separated symbols")):
    """Get latest prices for multiple symbols"""
    symbol_list = [s.strip().upper() for s in symbols.split(",")]
    prices = await market_data_service.get_multiple_prices(symbol_list)
    return {"symbols": prices}


@router.get("/market/history/{symbol}")
async def get_market_history(
    symbol: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    interval: str = "1d"
):
    """Get historical market data"""
    try:
        # Default to last 1 year
        if end_date is None:
            end_date = datetime.utcnow()
        else:
            end_date = datetime.fromisoformat(end_date)

        if start_date is None:
            start_date = end_date - timedelta(days=365)
        else:
            start_date = datetime.fromisoformat(start_date)

        df = await market_data_service.get_historical_data(symbol, start_date, end_date, interval)

        # Convert to list of dicts
        data = df.to_dict(orient='records')

        # Convert timestamps
        for record in data:
            if 'timestamp' in record:
                record['timestamp'] = record['timestamp'].isoformat()

        return {
            "symbol": symbol,
            "interval": interval,
            "data": data,
            "count": len(data)
        }
    except Exception as e:
        logger.error(f"Error getting market history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Indicators endpoints
@router.get("/indicators/{symbol}")
async def get_indicators(symbol: str):
    """Get current technical indicators for a symbol"""
    try:
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=60)

        df = await market_data_service.get_historical_data(symbol, start_date, end_date, "1d")
        df = indicators.calculate_all_indicators(df)

        current_indicators = indicators.get_current_indicators(df)

        return {
            "symbol": symbol,
            "timestamp": datetime.utcnow().isoformat(),
            "indicators": current_indicators
        }
    except Exception as e:
        logger.error(f"Error calculating indicators: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Strategy endpoints
@router.get("/strategies")
async def list_strategies():
    """List all available strategies"""
    strategies = StrategyRegistry.get_all_strategies()

    return {
        "strategies": [
            {
                "name": name,
                "description": info["description"],
                "parameters": info["default_parameters"]
            }
            for name, info in strategies.items()
        ]
    }


@router.get("/strategies/{strategy_name}")
async def get_strategy_info(strategy_name: str):
    """Get information about a specific strategy"""
    strategy = StrategyRegistry.get_strategy(strategy_name)

    if strategy is None:
        raise HTTPException(status_code=404, detail=f"Strategy '{strategy_name}' not found")

    return {
        "name": strategy.name,
        "default_parameters": strategy.get_default_parameters(),
        "description": strategy.__doc__ or ""
    }


# Backtest endpoints
@router.post("/backtest/run")
async def run_backtest(params: BacktestParameters):
    """Run a backtest"""
    try:
        # Convert dates
        start_date = params.start_date if isinstance(params.start_date, datetime) else datetime.fromisoformat(params.start_date)
        end_date = params.end_date if isinstance(params.end_date, datetime) else datetime.fromisoformat(params.end_date)

        # Get historical data
        df = await market_data_service.get_historical_data(params.symbol, start_date, end_date, "1d")

        if df.empty:
            raise HTTPException(status_code=400, detail="No data available for the specified date range")

        # Configure backtest
        config = BacktestConfig(
            strategy_name=params.strategy_name,
            symbol=params.symbol,
            start_date=start_date,
            end_date=end_date,
            initial_capital=params.initial_capital,
            commission=params.commission,
            slippage=params.slippage,
            parameters=params.parameters or {},
            risk_settings={
                'max_position_size': 0.1,
                'stop_loss_pct': 0.05,
                'take_profit_pct': 0.10,
            }
        )

        # Run backtest
        backtester = Backtester(config)
        report = backtester.run(df)

        # Convert report to response
        return {
            "status": "completed",
            "results": {
                "strategy_name": report.strategy_name,
                "symbol": report.symbol,
                "start_date": report.start_date.isoformat(),
                "end_date": report.end_date.isoformat(),
                "initial_capital": report.initial_capital,
                "final_capital": report.final_capital,
                "total_return": report.total_return,
                "cagr": report.cagr,
                "sharpe_ratio": report.sharpe_ratio,
                "sortino_ratio": report.sortino_ratio,
                "max_drawdown": report.max_drawdown,
                "max_drawdown_percent": report.max_drawdown_percent,
                "total_trades": report.total_trades,
                "profitable_trades": report.profitable_trades,
                "losing_trades": report.losing_trades,
                "win_rate": report.win_rate,
                "profit_factor": report.profit_factor,
                "avg_win": report.avg_win,
                "avg_loss": report.avg_loss,
                "avg_holding_period": report.avg_holding_period,
                "largest_win": report.largest_win,
                "largest_loss": report.largest_loss,
                "equity_curve": report.equity_curve[:100],  # Limit for response size
                "trades": report.trades[:50],  # Limit for response size
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Backtest error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/backtest/results")
async def get_backtest_results(limit: int = 10):
    """Get recent backtest results"""
    # In production, this would query the database
    return {
        "backtests": [],
        "count": 0
    }


# Risk Management endpoints
@router.get("/risk/status")
async def get_risk_status():
    """Get current risk management status"""
    return risk_manager.get_status()


@router.post("/risk/kill-switch")
async def toggle_kill_switch(engage: bool = True):
    """Toggle kill switch"""
    if engage:
        risk_manager.engage_kill_switch("Manual API trigger")
    else:
        risk_manager.disengage_kill_switch()

    return {
        "kill_switch_engaged": risk_manager.kill_switch_engaged,
        "message": "Kill switch engaged" if engage else "Kill switch disengenged"
    }


@router.post("/risk/reset-daily")
async def reset_daily_limits():
    """Reset daily risk limits"""
    risk_manager.reset_daily_limits()
    return {"message": "Daily limits reset"}


# Signal endpoints
@router.get("/signals/{symbol}")
async def get_signals(symbol: str, strategy: Optional[str] = None):
    """Get current trading signals for a symbol"""
    try:
        # Get market data
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=60)

        df = await market_data_service.get_historical_data(symbol, start_date, end_date, "1d")
        df = indicators.calculate_all_indicators(df)

        signals = []

        # If specific strategy requested
        if strategy:
            strategy_obj = StrategyRegistry.get_strategy(strategy)
            if strategy_obj:
                signal = strategy_obj.generate_signal(df, symbol)
                signals.append(signal.to_dict())
        else:
            # Generate signals for all strategies
            for strategy_name in StrategyRegistry.list_strategies():
                strategy_obj = StrategyRegistry.get_strategy(strategy_name)
                if strategy_obj:
                    signal = strategy_obj.generate_signal(df, symbol)
                    signals.append(signal.to_dict())

        return {
            "symbol": symbol,
            "timestamp": datetime.utcnow().isoformat(),
            "signals": signals
        }
    except Exception as e:
        logger.error(f"Error generating signals: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# WebSocket endpoint
@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket for real-time data streaming"""
    channel = websocket.query_params.get("channel", "market")

    await ws_manager.connect_websocket(websocket, channel)

    try:
        while True:
            # Keep connection alive, wait for messages
            data = await websocket.receive_text()
            message = json.loads(data)

            # Handle client messages
            if message.get("type") == "subscribe"):
                symbol = message.get("symbol")
                # Handle subscription
                logger.info(f"Client subscribed to {symbol}")

            elif message.get("type") == "ping"):
                await websocket.send_json({"type": "pong"})

    except WebSocketDisconnect:
        ws_manager.disconnect_websocket(websocket, channel)
        logger.info("WebSocket client disconnected")


# Watchlist endpoints
@router.get("/watchlist")
async def get_watchlist():
    """Get user's watchlist"""
    # Sample watchlist
    return {
        "watchlist": [
            {"symbol": "AAPL", "name": "Apple Inc."},
            {"symbol": "GOOGL", "name": "Alphabet Inc."},
            {"symbol": "MSFT", "name": "Microsoft Corporation"},
            {"symbol": "AMZN", "name": "Amazon.com Inc."},
            {"symbol": "TSLA", "name": "Tesla Inc."},
            {"symbol": "SPY", "name": "SPDR S&P 500 ETF"},
            {"symbol": "QQQ", "name": "Invesco QQQ Trust"},
        ]
    }


@router.post("/watchlist")
async def add_to_watchlist(item: WatchlistCreate):
    """Add symbol to watchlist"""
    return {
        "symbol": item.symbol,
        "name": item.name or item.symbol,
        "message": "Added to watchlist"
    }


@router.delete("/watchlist/{symbol}")
async def remove_from_watchlist(symbol: str):
    """Remove symbol from watchlist"""
    return {"message": f"{symbol} removed from watchlist"}
