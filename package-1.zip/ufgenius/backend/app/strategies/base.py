"""
Strategy Base Classes and Registry
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from enum import Enum
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class SignalType(str, Enum):
    """Trading signal types"""
    BUY = "BUY"
    SELL = "SELL"
    HOLD = "HOLD"


@dataclass
class TradingSignal:
    """Trading signal with metadata"""
    symbol: str
    signal_type: SignalType
    strength: float = 0.0  # 0-1 confidence
    price: float = 0.0
    indicators: Dict[str, Any] = field(default_factory=dict)
    strategy_name: str = ""
    message: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "symbol": self.symbol,
            "signal_type": self.signal_type.value,
            "strength": self.strength,
            "price": self.price,
            "indicators": self.indicators,
            "strategy_name": self.strategy_name,
            "message": self.message,
        }


@dataclass
class StrategyConfig:
    """Strategy configuration"""
    name: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    risk_settings: Dict[str, Any] = field(default_factory=dict)

    def get(self, key: str, default: Any = None) -> Any:
        """Get parameter value"""
        return self.parameters.get(key, default)


class BaseStrategy(ABC):
    """
    Abstract base class for all trading strategies
    """

    def __init__(self, config: StrategyConfig):
        self.config = config
        self.name = config.name
        self.parameters = config.parameters
        self.risk_settings = config.risk_settings
        self._initialize_parameters()

    def _initialize_parameters(self):
        """Initialize default parameters - override in subclass"""
        pass

    @abstractmethod
    def generate_signal(
        self,
        df: pd.DataFrame,
        symbol: str
    ) -> TradingSignal:
        """
        Generate trading signal from market data

        Args:
            df: DataFrame with OHLCV data and indicators
            symbol: Trading symbol

        Returns:
            TradingSignal with signal type and metadata
        """
        pass

    @abstractmethod
    def get_default_parameters(self) -> Dict[str, Any]:
        """Get default strategy parameters"""
        pass

    def validate_parameters(self) -> bool:
        """Validate strategy parameters"""
        return True

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.name})"


class StrategyRegistry:
    """
    Registry for all available strategies
    """

    _strategies: Dict[str, type] = {}

    @classmethod
    def register(cls, name: str):
        """Decorator to register a strategy"""
        def decorator(strategy_class: type):
            cls._strategies[name] = strategy_class
            return strategy_class
        return decorator

    @classmethod
    def get_strategy(cls, name: str, config: Optional[StrategyConfig] = None) -> Optional[BaseStrategy]:
        """Get strategy instance by name"""
        if name not in cls._strategies:
            logger.warning(f"Strategy '{name}' not found in registry")
            return None

        if config is None:
            strategy_class = cls._strategies[name]
            config = StrategyConfig(
                name=name,
                parameters=strategy_class.get_default_parameters()
            )

        return cls._strategies[name](config)

    @classmethod
    def list_strategies(cls) -> List[str]:
        """List all registered strategy names"""
        return list(cls._strategies.keys())

    @classmethod
    def get_all_strategies(cls) -> Dict[str, Dict[str, Any]]:
        """Get all strategies with their default parameters"""
        result = {}
        for name, strategy_class in cls._strategies.items():
            config = StrategyConfig(name=name)
            strategy = strategy_class(config)
            result[name] = {
                "default_parameters": strategy.get_default_parameters(),
                "description": strategy.__doc__ or "",
            }
        return result
