"""
Strategies module initialization
"""
from app.strategies.base import (
    BaseStrategy,
    StrategyRegistry,
    StrategyConfig,
    TradingSignal,
    SignalType,
)
from app.strategies.impl import (
    RSIMeanReversionStrategy,
    MACDCrossoverStrategy,
    BollingerBreakoutStrategy,
    MovingAverageCrossoverStrategy,
    ATRBreakoutStrategy,
)

# Import to register strategies
_ = RSIMeanReversionStrategy, MACDCrossoverStrategy, BollingerBreakoutStrategy, MovingAverageCrossoverStrategy, ATRBreakoutStrategy

__all__ = [
    "BaseStrategy",
    "StrategyRegistry",
    "StrategyConfig",
    "TradingSignal",
    "SignalType",
    "RSIMeanReversionStrategy",
    "MACDCrossoverStrategy",
    "BollingerBreakoutStrategy",
    "MovingAverageCrossoverStrategy",
    "ATRBreakoutStrategy",
]
