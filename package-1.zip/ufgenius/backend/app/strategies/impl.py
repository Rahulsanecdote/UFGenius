"""
Strategy Implementations
"""
import pandas as pd
import numpy as np
from typing import Dict, Any

from app.strategies.base import (
    BaseStrategy,
    StrategyRegistry,
    StrategyConfig,
    TradingSignal,
    SignalType,
)


@StrategyRegistry.register("rsi_mean_reversion")
class RSIMeanReversionStrategy(BaseStrategy):
    """
    RSI Mean Reversion Strategy

    Buy when RSI is oversold (< 30) expecting price to bounce back
    Sell when RSI is overbought (> 70) expecting price to correct

    Parameters:
        rsi_period: RSI calculation period (default: 14)
        oversold_threshold: RSI level for buy signal (default: 30)
        overbought_threshold: RSI level for sell signal (default: 70)
    """

    def _initialize_parameters(self):
        self.rsi_period = self.parameters.get("rsi_period", 14)
        self.oversold_threshold = self.parameters.get("oversold_threshold", 30)
        self.overbought_threshold = self.parameters.get("overbought_threshold", 70)

    def get_default_parameters(self) -> Dict[str, Any]:
        return {
            "rsi_period": 14,
            "oversold_threshold": 30,
            "overbought_threshold": 70,
        }

    def generate_signal(self, df: pd.DataFrame, symbol: str) -> TradingSignal:
        """Generate RSI mean reversion signal"""
        if df.empty or len(df) < self.rsi_period + 1:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=df['close'].iloc[-1] if not df.empty else 0,
                strategy_name=self.name,
                message="Insufficient data for RSI calculation"
            )

        latest = df.iloc[-1]
        rsi = latest.get('rsi')

        if pd.isna(rsi):
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=latest['close'],
                strategy_name=self.name,
                message="RSI not available"
            )

        # Calculate signal strength based on RSI distance from thresholds
        if rsi < self.oversold_threshold:
            # Oversold - BUY signal
            distance = self.oversold_threshold - rsi
            strength = min(distance / self.oversold_threshold, 1.0)
            message = f"RSI oversold at {rsi:.2f} - BUY signal"

            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.BUY,
                strength=strength,
                price=latest['close'],
                indicators={"rsi": rsi},
                strategy_name=self.name,
                message=message
            )

        elif rsi > self.overbought_threshold:
            # Overbought - SELL signal
            distance = rsi - self.overbought_threshold
            strength = min(distance / (100 - self.overbought_threshold), 1.0)
            message = f"RSI overbought at {rsi:.2f} - SELL signal"

            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.SELL,
                strength=strength,
                price=latest['close'],
                indicators={"rsi": rsi},
                strategy_name=self.name,
                message=message
            )

        else:
            # Neutral zone
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=latest['close'],
                indicators={"rsi": rsi},
                strategy_name=self.name,
                message=f"RSI neutral at {rsi:.2f}"
            )


@StrategyRegistry.register("macd_crossover")
class MACDCrossoverStrategy(BaseStrategy):
    """
    MACD Crossover Strategy

    Buy when MACD line crosses above signal line (bullish)
    Sell when MACD line crosses below signal line (bearish)

    Parameters:
        fast_period: Fast EMA period (default: 12)
        slow_period: Slow EMA period (default: 26)
        signal_period: Signal line period (default: 9)
    """

    def _initialize_parameters(self):
        self.fast_period = self.parameters.get("fast_period", 12)
        self.slow_period = self.parameters.get("slow_period", 26)
        self.signal_period = self.parameters.get("signal_period", 9)

    def get_default_parameters(self) -> Dict[str, Any]:
        return {
            "fast_period": 12,
            "slow_period": 26,
            "signal_period": 9,
        }

    def generate_signal(self, df: pd.DataFrame, symbol: str) -> TradingSignal:
        """Generate MACD crossover signal"""
        if df.empty or len(df) < self.slow_period + self.signal_period:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=df['close'].iloc[-1] if not df.empty else 0,
                strategy_name=self.name,
                message="Insufficient data for MACD calculation"
            )

        latest = df.iloc[-1]
        prev = df.iloc[-2]

        macd = latest.get('macd')
        signal = latest.get('macd_signal')
        histogram = latest.get('macd_histogram')

        prev_macd = prev.get('macd')
        prev_signal = prev.get('macd_signal')

        if any(pd.isna(x) for x in [macd, signal, prev_macd, prev_signal]):
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=latest['close'],
                strategy_name=self.name,
                message="MACD not available"
            )

        # Check for crossover
        # Bullish crossover: MACD crosses above signal
        if prev_macd <= prev_signal and macd > signal:
            strength = min(abs(histogram) / 2 if histogram else 0.5, 1.0)
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.BUY,
                strength=strength,
                price=latest['close'],
                indicators={
                    "macd": macd,
                    "signal": signal,
                    "histogram": histogram
                },
                strategy_name=self.name,
                message=f"MACD bullish crossover - BUY signal"
            )

        # Bearish crossover: MACD crosses below signal
        elif prev_macd >= prev_signal and macd < signal:
            strength = min(abs(histogram) / 2 if histogram else 0.5, 1.0)
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.SELL,
                strength=strength,
                price=latest['close'],
                indicators={
                    "macd": macd,
                    "signal": signal,
                    "histogram": histogram
                },
                strategy_name=self.name,
                message=f"MACD bearish crossover - SELL signal"
            )

        # Check for strong momentum without crossover
        elif histogram > 0 and histogram > abs(histogram) * 0.5:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.BUY,
                strength=0.3,
                price=latest['close'],
                indicators={"macd": macd, "signal": signal, "histogram": histogram},
                strategy_name=self.name,
                message="MACD momentum bullish - potential BUY"
            )

        elif histogram < 0 and abs(histogram) > abs(histogram) * 0.5:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.SELL,
                strength=0.3,
                price=latest['close'],
                indicators={"macd": macd, "signal": signal, "histogram": histogram},
                strategy_name=self.name,
                message="MACD momentum bearish - potential SELL"
            )

        else:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=latest['close'],
                indicators={"macd": macd, "signal": signal, "histogram": histogram},
                strategy_name=self.name,
                message="No MACD crossover"
            )


@StrategyRegistry.register("bollinger_breakout")
class BollingerBreakoutStrategy(BaseStrategy):
    """
    Bollinger Breakout Strategy

    Buy when price breaks above upper Bollinger Band
    Sell when price breaks below lower Bollinger Band

    Parameters:
        period: Bollinger Bands period (default: 20)
        std_dev: Standard deviation multiplier (default: 2.0)
    """

    def _initialize_parameters(self):
        self.period = self.parameters.get("period", 20)
        self.std_dev = self.parameters.get("std_dev", 2.0)

    def get_default_parameters(self) -> Dict[str, Any]:
        return {
            "period": 20,
            "std_dev": 2.0,
        }

    def generate_signal(self, df: pd.DataFrame, symbol: str) -> TradingSignal:
        """Generate Bollinger breakout signal"""
        if df.empty or len(df) < self.period + 1:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=df['close'].iloc[-1] if not df.empty else 0,
                strategy_name=self.name,
                message="Insufficient data for Bollinger Bands"
            )

        latest = df.iloc[-1]
        close = latest['close']
        bb_upper = latest.get('bb_upper')
        bb_middle = latest.get('bb_middle')
        bb_lower = latest.get('bb_lower')

        if any(pd.isna(x) for x in [bb_upper, bb_middle, bb_lower]):
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=close,
                strategy_name=self.name,
                message="Bollinger Bands not available"
            )

        # Calculate position within bands
        band_width = bb_upper - bb_lower
        position = (close - bb_lower) / band_width if band_width > 0 else 0.5

        # Buy signal: price breaks above upper band
        if close > bb_upper:
            strength = min((close - bb_upper) / band_width * 2, 1.0) if band_width > 0 else 0.5
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.BUY,
                strength=strength,
                price=close,
                indicators={
                    "bb_upper": bb_upper,
                    "bb_middle": bb_middle,
                    "bb_lower": bb_lower,
                    "position": position
                },
                strategy_name=self.name,
                message=f"Price breakout above upper band - BUY signal"
            )

        # Sell signal: price breaks below lower band
        elif close < bb_lower:
            strength = min((bb_lower - close) / band_width * 2, 1.0) if band_width > 0 else 0.5
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.SELL,
                strength=strength,
                price=close,
                indicators={
                    "bb_upper": bb_upper,
                    "bb_middle": bb_middle,
                    "bb_lower": bb_lower,
                    "position": position
                },
                strategy_name=self.name,
                message=f"Price breakdown below lower band - SELL signal"
            )

        # Near upper band - potential reversal
        elif position > 0.8:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0.3,
                price=close,
                indicators={
                    "bb_upper": bb_upper,
                    "bb_middle": bb_middle,
                    "bb_lower": bb_lower,
                    "position": position
                },
                strategy_name=self.name,
                message="Price near upper band - caution"
            )

        # Near lower band - potential bounce
        elif position < 0.2:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0.3,
                price=close,
                indicators={
                    "bb_upper": bb_upper,
                    "bb_middle": bb_middle,
                    "bb_lower": bb_lower,
                    "position": position
                },
                strategy_name=self.name,
                message="Price near lower band - potential bounce"
            )

        else:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=close,
                indicators={
                    "bb_upper": bb_upper,
                    "bb_middle": bb_middle,
                    "bb_lower": bb_lower,
                    "position": position
                },
                strategy_name=self.name,
                message="Price within Bollinger Bands"
            )


@StrategyRegistry.register("moving_average_crossover")
class MovingAverageCrossoverStrategy(BaseStrategy):
    """
    Moving Average Crossover Strategy (Golden/Death Cross)

    Buy when fast MA crosses above slow MA (Golden Cross)
    Sell when fast MA crosses below slow MA (Death Cross)

    Parameters:
        fast_period: Fast MA period (default: 50)
        slow_period: Slow MA period (default: 200)
    """

    def _initialize_parameters(self):
        self.fast_period = self.parameters.get("fast_period", 50)
        self.slow_period = self.parameters.get("slow_period", 200)

    def get_default_parameters(self) -> Dict[str, Any]:
        return {
            "fast_period": 50,
            "slow_period": 200,
        }

    def generate_signal(self, df: pd.DataFrame, symbol: str) -> TradingSignal:
        """Generate moving average crossover signal"""
        if df.empty or len(df) < max(self.fast_period, self.slow_period) + 1:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=df['close'].iloc[-1] if not df.empty else 0,
                strategy_name=self.name,
                message="Insufficient data for MA crossover"
            )

        latest = df.iloc[-1]
        prev = df.iloc[-2]

        fast_ma_col = f'sma_{self.fast_period}'
        slow_ma_col = f'sma_{self.slow_period}'

        fast_ma = latest.get(fast_ma_col)
        slow_ma = latest.get(slow_ma_col)
        prev_fast_ma = prev.get(fast_ma_col)
        prev_slow_ma = prev.get(slow_ma_col)

        if any(pd.isna(x) for x in [fast_ma, slow_ma, prev_fast_ma, prev_slow_ma]):
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=latest['close'],
                strategy_name=self.name,
                message="Moving averages not available"
            )

        # Golden Cross: Fast MA crosses above Slow MA
        if prev_fast_ma <= prev_slow_ma and fast_ma > slow_ma:
            strength = min(abs(fast_ma - slow_ma) / slow_ma * 5, 1.0)
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.BUY,
                strength=strength,
                price=latest['close'],
                indicators={
                    "fast_ma": fast_ma,
                    "slow_ma": slow_ma,
                    "crossover": "golden"
                },
                strategy_name=self.name,
                message=f"Golden Cross: {self.fast_period}-MA crossed above {self.slow_period}-MA"
            )

        # Death Cross: Fast MA crosses below Slow MA
        elif prev_fast_ma >= prev_slow_ma and fast_ma < slow_ma:
            strength = min(abs(fast_ma - slow_ma) / slow_ma * 5, 1.0)
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.SELL,
                strength=strength,
                price=latest['close'],
                indicators={
                    "fast_ma": fast_ma,
                    "slow_ma": slow_ma,
                    "crossover": "death"
                },
                strategy_name=self.name,
                message=f"Death Cross: {self.fast_period}-MA crossed below {self.slow_period}-MA"
            )

        # Trend direction without crossover
        elif fast_ma > slow_ma:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0.2,
                price=latest['close'],
                indicators={"fast_ma": fast_ma, "slow_ma": slow_ma},
                strategy_name=self.name,
                message=f"Uptrend: Fast MA above slow MA"
            )

        else:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0.2,
                price=latest['close'],
                indicators={"fast_ma": fast_ma, "slow_ma": slow_ma},
                strategy_name=self.name,
                message=f"Downtrend: Fast MA below slow MA"
            )


@StrategyRegistry.register("atr_breakout")
class ATRBreakoutStrategy(BaseStrategy):
    """
    ATR Breakout Strategy

    Buy when price breaks above recent high + ATR (volatility breakout)
    Sell when price breaks below recent low - ATR

    Parameters:
        atr_period: ATR calculation period (default: 14)
        multiplier: ATR multiplier for breakout threshold (default: 2.0)
    """

    def _initialize_parameters(self):
        self.atr_period = self.parameters.get("atr_period", 14)
        self.multiplier = self.parameters.get("multiplier", 2.0)

    def get_default_parameters(self) -> Dict[str, Any]:
        return {
            "atr_period": 14,
            "multiplier": 2.0,
        }

    def generate_signal(self, df: pd.DataFrame, symbol: str) -> TradingSignal:
        """Generate ATR breakout signal"""
        if df.empty or len(df) < self.atr_period + 2:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=df['close'].iloc[-1] if not df.empty else 0,
                strategy_name=self.name,
                message="Insufficient data for ATR breakout"
            )

        latest = df.iloc[-1]
        prev = df.iloc[-2]
        close = latest['close']
        atr = latest.get('atr')

        if pd.isna(atr) or atr == 0:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=close,
                strategy_name=self.name,
                message="ATR not available"
            )

        # Calculate breakout thresholds
        prev_high = prev['high']
        prev_low = prev['low']

        upper_threshold = prev_high + (self.multiplier * atr)
        lower_threshold = prev_low - (self.multiplier * atr)

        # Buy signal: price breaks above upper threshold
        if close > upper_threshold:
            strength = min((close - upper_threshold) / atr, 1.0)
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.BUY,
                strength=strength,
                price=close,
                indicators={
                    "atr": atr,
                    "upper_threshold": upper_threshold,
                    "lower_threshold": lower_threshold,
                    "breakout": "up"
                },
                strategy_name=self.name,
                message=f"ATR breakout: Price above {self.multiplier}x ATR"
            )

        # Sell signal: price breaks below lower threshold
        elif close < lower_threshold:
            strength = min((lower_threshold - close) / atr, 1.0)
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.SELL,
                strength=strength,
                price=close,
                indicators={
                    "atr": atr,
                    "upper_threshold": upper_threshold,
                    "lower_threshold": lower_threshold,
                    "breakout": "down"
                },
                strategy_name=self.name,
                message=f"ATR breakdown: Price below {self.multiplier}x ATR"
            )

        # Near breakout
        elif close > upper_threshold - atr:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0.3,
                price=close,
                indicators={"atr": atr, "upper_threshold": upper_threshold},
                strategy_name=self.name,
                message="Near ATR breakout threshold"
            )

        elif close < lower_threshold + atr:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0.3,
                price=close,
                indicators={"atr": atr, "lower_threshold": lower_threshold},
                strategy_name=self.name,
                message="Near ATR breakdown threshold"
            )

        else:
            return TradingSignal(
                symbol=symbol,
                signal_type=SignalType.HOLD,
                strength=0,
                price=close,
                indicators={"atr": atr},
                strategy_name=self.name,
                message="No ATR breakout"
            )
