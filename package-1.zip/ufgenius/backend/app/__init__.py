"""
App module initialization
"""
