"""
Application Configuration
"""
from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings"""

    # Application
    APP_NAME: str = "Universal Financial Genius"
    DEBUG: bool = True
    LOG_LEVEL: str = "INFO"

    # Database
    DATABASE_URL: str = "postgresql://ufgenius:ufgenius@localhost:5432/ufgenius"

    # Redis
    REDIS_URL: str = "redis://localhost:6379"

    # API Keys (for market data)
    ALPHA_VANTAGE_API_KEY: str = ""
    FINNHUB_API_KEY: str = ""

    # Trading Settings
    DEFAULT_INITIAL_CAPITAL: float = 100000.0
    DEFAULT_COMMISSION: float = 0.001  # 0.1%
    DEFAULT_SLIPPAGE: float = 0.001    # 0.1%

    # Risk Management Defaults
    DEFAULT_MAX_POSITION_SIZE: float = 0.1  # 10% of portfolio
    DEFAULT_MAX_DRAWDOWN: float = 0.15       # 15%
    DEFAULT_DAILY_LOSS_LIMIT: float = 0.05   # 5%

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings"""
    return Settings()


settings = get_settings()
