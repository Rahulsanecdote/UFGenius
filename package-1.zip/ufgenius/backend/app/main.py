"""
Universal Financial Genius - Main Application
Production-grade algorithmic trading platform
"""
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import routes
from app.core.config import settings
from app.core.database import init_db
from app.services.websocket_manager import ws_manager

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler"""
    logger.info("Starting Universal Financial Genius Backend...")

    # Initialize database
    await init_db()
    logger.info("Database initialized")

    # Start WebSocket manager
    await ws_manager.connect()
    logger.info("WebSocket manager started")

    yield

    # Cleanup
    await ws_manager.disconnect()
    logger.info("Shutting down Universal Financial Genius Backend...")


# Create FastAPI application
app = FastAPI(
    title="Universal Financial Genius API",
    description="Production-grade algorithmic trading and financial analysis platform",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(routes.router, prefix="/api/v1")


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "Universal Financial Genius",
        "version": "1.0.0",
        "status": "operational",
        "docs": "/docs",
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "database": "connected",
        "websocket": "active",
    }
