"""
WebSocket Manager
Real-time market data streaming and broadcasting
"""
import asyncio
import json
import logging
from typing import Dict, Set, Optional, Any
from datetime import datetime
from fastapi import WebSocket
import aiohttp

from app.core.config import settings

logger = logging.getLogger(__name__)


class WebSocketManager:
    """
    WebSocket connection manager for real-time data streaming
    """

    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = {
            'market': set(),      # Market data subscribers
            'signals': set(),     # Trading signals subscribers
            'system': set(),      # System status subscribers
        }
        self.market_data_cache: Dict[str, Dict[str, Any]] = {}
        self.is_connected = False

    async def connect(self):
        """Initialize WebSocket connections"""
        logger.info("WebSocket manager connecting...")
        self.is_connected = True

    async def disconnect(self):
        """Disconnect all WebSocket connections"""
        logger.info("WebSocket manager disconnecting...")
        for channel in self.active_connections:
            self.active_connections[channel].clear()
        self.is_connected = False

    async def connect_websocket(self, websocket: WebSocket, channel: str):
        """Connect a WebSocket client to a channel"""
        await websocket.accept()

        if channel not in self.active_connections:
            self.active_connections[channel] = set()

        self.active_connections[channel].add(websocket)
        logger.info(f"WebSocket client connected to {channel} channel")

    def disconnect_websocket(self, websocket: WebSocket, channel: str):
        """Disconnect a WebSocket client from a channel"""
        if channel in self.active_connections:
            self.active_connections[channel].discard(websocket)
            logger.info(f"WebSocket client disconnected from {channel} channel")

    async def broadcast(self, channel: str, message: Dict[str, Any]):
        """Broadcast message to all clients in a channel"""
        if channel not in self.active_connections:
            return

        disconnected = set()

        for connection in self.active_connections[channel]:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to WebSocket: {e}")
                disconnected.add(connection)

        # Clean up disconnected clients
        for conn in disconnected:
            self.disconnect_websocket(conn, channel)

    async def broadcast_market_data(self, symbol: str, data: Dict[str, Any]):
        """Broadcast market data to market channel"""
        # Cache latest data
        self.market_data_cache[symbol] = {
            **data,
            'timestamp': datetime.utcnow().isoformat()
        }

        # Broadcast to all market subscribers
        await self.broadcast('market', {
            'type': 'market_data',
            'symbol': symbol,
            'data': data
        })

    async def broadcast_signal(self, signal: Dict[str, Any]):
        """Broadcast trading signal to signals channel"""
        await self.broadcast('signals', {
            'type': 'signal',
            'data': signal
        })

    async def broadcast_system_status(self, status: Dict[str, Any]):
        """Broadcast system status to system channel"""
        await self.broadcast('system', {
            'type': 'status',
            'data': status
        })

    def get_subscribers_count(self, channel: str) -> int:
        """Get number of subscribers in a channel"""
        return len(self.active_connections.get(channel, set()))

    def get_cached_market_data(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get cached market data for a symbol"""
        return self.market_data_cache.get(symbol)


# Global WebSocket manager instance
ws_manager = WebSocketManager()
