"""
Technical Indicator Engine
Vectorized computation using pandas and numpy
"""
import numpy as np
import pandas as pd
from typing import Dict, Optional, Tuple, List
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class IndicatorResult:
    """Indicator calculation result"""
    name: str
    value: float
    is_valid: bool
    message: Optional[str] = None


class TechnicalIndicators:
    """
    Technical indicator calculations using pandas
    Industry-standard formulas with proper edge case handling
    """

    @staticmethod
    def calculate_rsi(
        data: pd.Series,
        period: int = 14
    ) -> pd.Series:
        """
        Calculate Relative Strength Index (RSI)
        Formula: 100 - (100 / (1 + RS))
        Where RS = Average Gain / Average Loss over period
        Returns: Series with values 0-100, NaN for insufficient data
        """
        if len(data) < period + 1:
            return pd.Series([np.nan] * len(data), index=data.index)

        # Calculate price changes
        delta = data.diff()

        # Separate gains and losses
        gains = delta.where(delta > 0, 0)
        losses = (-delta).where(delta < 0, 0)

        # Calculate average gains and losses using exponential moving average
        avg_gain = gains.ewm(com=period - 1, min_periods=period).mean()
        avg_loss = losses.ewm(com=period - 1, min_periods=period).mean()

        # Calculate RS and RSI
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))

        # Clip to valid range
        rsi = rsi.clip(0, 100)

        return rsi

    @staticmethod
    def calculate_macd(
        data: pd.Series,
        fast_period: int = 12,
        slow_period: int = 26,
        signal_period: int = 9
    ) -> pd.DataFrame:
        """
        Calculate MACD (Moving Average Convergence Divergence)
        Formula:
        - MACD Line = Fast EMA - Slow EMA
        - Signal Line = EMA of MACD Line
        - Histogram = MACD Line - Signal Line
        Returns: DataFrame with macd, signal, histogram
        """
        if len(data) < slow_period + signal_period:
            return pd.DataFrame({
                'macd': [np.nan] * len(data),
                'signal': [np.nan] * len(data),
                'histogram': [np.nan] * len(data)
            }, index=data.index)

        # Calculate EMAs
        fast_ema = data.ewm(span=fast_period, adjust=False).mean()
        slow_ema = data.ewm(span=slow_period, adjust=False).mean()

        # MACD line
        macd_line = fast_ema - slow_ema

        # Signal line
        signal_line = macd_line.ewm(span=signal_period, adjust=False).mean()

        # Histogram
        histogram = macd_line - signal_line

        return pd.DataFrame({
            'macd': macd_line,
            'signal': signal_line,
            'histogram': histogram
        }, index=data.index)

    @staticmethod
    def calculate_bollinger_bands(
        data: pd.Series,
        period: int = 20,
        std_dev: float = 2.0
    ) -> pd.DataFrame:
        """
        Calculate Bollinger Bands
        Formula:
        - Middle Band = SMA(period)
        - Upper Band = Middle Band + (std_dev * STD)
        - Lower Band = Middle Band - (std_dev * STD)
        Returns: DataFrame with upper, middle, lower bands
        """
        if len(data) < period:
            return pd.DataFrame({
                'upper': [np.nan] * len(data),
                'middle': [np.nan] * len(data),
                'lower': [np.nan] * len(data)
            }, index=data.index)

        # Calculate middle band (SMA)
        middle = data.rolling(window=period).mean()

        # Calculate standard deviation
        std = data.rolling(window=period).std()

        # Calculate bands
        upper = middle + (std_dev * std)
        lower = middle - (std_dev * std)

        return pd.DataFrame({
            'upper': upper,
            'middle': middle,
            'lower': lower
        }, index=data.index)

    @staticmethod
    def calculate_sma(
        data: pd.Series,
        periods: List[int] = None
    ) -> pd.DataFrame:
        """
        Calculate Simple Moving Average (SMA)
        Formula: Sum of last N prices / N
        """
        if periods is None:
            periods = [20, 50, 200]

        result = pd.DataFrame(index=data.index)

        for period in periods:
            if len(data) >= period:
                result[f'sma_{period}'] = data.rolling(window=period).mean()
            else:
                result[f'sma_{period}'] = np.nan

        return result

    @staticmethod
    def calculate_ema(
        data: pd.Series,
        periods: List[int] = None
    ) -> pd.DataFrame:
        """
        Calculate Exponential Moving Average (EMA)
        Formula: (Price * k) + (EMA_previous * (1 - k))
        Where k = 2 / (N + 1)
        """
        if periods is None:
            periods = [12, 26]

        result = pd.DataFrame(index=data.index)

        for period in periods:
            if len(data) >= period:
                result[f'ema_{period}'] = data.ewm(span=period, adjust=False).mean()
            else:
                result[f'ema_{period}'] = np.nan

        return result

    @staticmethod
    def calculate_atr(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        period: int = 14
    ) -> pd.Series:
        """
        Calculate Average True Range (ATR)
        Formula: Average of True Range over N periods
        Where True Range = max of:
        - High - Low
        - |High - Previous Close|
        - |Low - Previous Close|
        """
        if len(high) < period + 1:
            return pd.Series([np.nan] * len(high), index=high.index)

        # Calculate True Range components
        tr1 = high - low
        tr2 = (high - close.shift(1)).abs()
        tr3 = (low - close.shift(1)).abs()

        # True Range is the max of the three
        true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

        # ATR is the exponential moving average of True Range
        atr = true_range.ewm(com=period - 1, min_periods=period).mean()

        return atr

    @staticmethod
    def calculate_all_indicators(
        df: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Calculate all technical indicators for a DataFrame with OHLCV data
        """
        result = df.copy()

        # RSI
        if 'close' in result.columns:
            result['rsi'] = TechnicalIndicators.calculate_rsi(result['close'])

            # MACD
            macd_df = TechnicalIndicators.calculate_macd(result['close'])
            result['macd'] = macd_df['macd']
            result['macd_signal'] = macd_df['signal']
            result['macd_histogram'] = macd_df['histogram']

            # Bollinger Bands
            bb_df = TechnicalIndicators.calculate_bollinger_bands(result['close'])
            result['bb_upper'] = bb_df['upper']
            result['bb_middle'] = bb_df['middle']
            result['bb_lower'] = bb_df['lower']

            # SMA
            sma_df = TechnicalIndicators.calculate_sma(result['close'])
            for col in sma_df.columns:
                result[col] = sma_df[col]

            # EMA
            ema_df = TechnicalIndicators.calculate_ema(result['close'])
            for col in ema_df.columns:
                result[col] = ema_df[col]

        # ATR (requires high, low, close)
        if all(col in result.columns for col in ['high', 'low', 'close']):
            result['atr'] = TechnicalIndicators.calculate_atr(
                result['high'],
                result['low'],
                result['close']
            )

        return result

    @staticmethod
    def get_current_indicators(
        df: pd.DataFrame
    ) -> Dict:
        """
        Get current indicator values from the most recent bar
        """
        if df.empty or len(df) < 2:
            return {}

        latest = df.iloc[-1]
        prev = df.iloc[-2]

        indicators = {}

        # RSI
        if 'rsi' in df.columns and not pd.isna(latest.get('rsi')):
            indicators['rsi'] = float(latest['rsi'])

        # MACD
        if all(col in df.columns for col in ['macd', 'macd_signal', 'macd_histogram']):
            if not pd.isna(latest.get('macd')):
                indicators['macd'] = {
                    'macd': float(latest['macd']),
                    'signal': float(latest['macd_signal']),
                    'histogram': float(latest['macd_histogram'])
                }

        # Bollinger Bands
        if all(col in df.columns for col in ['bb_upper', 'bb_middle', 'bb_lower']):
            if not pd.isna(latest.get('bb_upper')):
                indicators['bollinger_bands'] = {
                    'upper': float(latest['bb_upper']),
                    'middle': float(latest['bb_middle']),
                    'lower': float(latest['bb_lower']),
                    'position': float((latest['close'] - latest['bb_lower']) /
                                     (latest['bb_upper'] - latest['bb_lower']))
                    if latest['bb_upper'] != latest['bb_lower'] else 0
                }

        # SMA
        sma_cols = [col for col in df.columns if col.startswith('sma_')]
        if sma_cols:
            sma_values = {}
            for col in sma_cols:
                if not pd.isna(latest.get(col)):
                    sma_values[col] = float(latest[col])
            if sma_values:
                indicators['sma'] = sma_values

        # EMA
        ema_cols = [col for col in df.columns if col.startswith('ema_')]
        if ema_cols:
            ema_values = {}
            for col in ema_cols:
                if not pd.isna(latest.get(col)):
                    ema_values[col] = float(latest[col])
            if ema_values:
                indicators['ema'] = ema_values

        # ATR
        if 'atr' in df.columns and not pd.isna(latest.get('atr')):
            indicators['atr'] = float(latest['atr'])

        return indicators


# Singleton instance
indicators = TechnicalIndicators()
