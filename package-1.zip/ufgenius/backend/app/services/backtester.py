"""
Backtesting Framework
Event-driven backtesting engine with realistic simulation
"""
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
import logging

from app.strategies.base import StrategyRegistry, StrategyConfig, TradingSignal, SignalType
from app.services.indicators import TechnicalIndicators

logger = logging.getLogger(__name__)


@dataclass
class Trade:
    """Trade record"""
    entry_date: datetime
    exit_date: datetime
    symbol: str
    side: str  # LONG or SHORT
    entry_price: float
    exit_price: float
    quantity: float
    pnl: float
    pnl_percent: float
    commission: float
    holding_period: int  # bars
    strategy_name: str


@dataclass
class BacktestConfig:
    """Backtest configuration"""
    strategy_name: str
    symbol: str
    start_date: datetime
    end_date: datetime
    initial_capital: float = 100000.0
    commission: float = 0.001  # 0.1%
    slippage: float = 0.001    # 0.1%
    parameters: Dict[str, Any] = field(default_factory=dict)
    risk_settings: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BacktestReport:
    """Backtest results report"""
    # Configuration
    strategy_name: str
    symbol: str
    start_date: datetime
    end_date: datetime
    initial_capital: float
    final_capital: float

    # Performance metrics
    total_return: float
    cagr: float
    sharpe_ratio: Optional[float]
    sortino_ratio: Optional[float]
    max_drawdown: float
    max_drawdown_percent: float

    # Trade statistics
    total_trades: int
    profitable_trades: int
    losing_trades: int
    win_rate: float
    profit_factor: float
    avg_win: float
    avg_loss: float
    avg_holding_period: float
    largest_win: float
    largest_loss: float

    # Additional data
    equity_curve: List[Dict[str, Any]] = field(default_factory=list)
    trades: List[Dict[str, Any]] = field(default_factory=list)
    drawdown_curve: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "strategy_name": self.strategy_name,
            "symbol": self.symbol,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "initial_capital": self.initial_capital,
            "final_capital": self.final_capital,
            "total_return": self.total_return,
            "cagr": self.cagr,
            "sharpe_ratio": self.sharpe_ratio,
            "sortino_ratio": self.sortino_ratio,
            "max_drawdown": self.max_drawdown,
            "max_drawdown_percent": self.max_drawdown_percent,
            "total_trades": self.total_trades,
            "profitable_trades": self.profitable_trades,
            "losing_trades": self.losing_trades,
            "win_rate": self.win_rate,
            "profit_factor": self.profit_factor,
            "avg_win": self.avg_win,
            "avg_loss": self.avg_loss,
            "avg_holding_period": self.avg_holding_period,
            "largest_win": self.largest_win,
            "largest_loss": self.largest_loss,
            "equity_curve": self.equity_curve,
            "trades": self.trades,
            "drawdown_curve": self.drawdown_curve,
        }


class Backtester:
    """
    Event-driven backtesting engine
    """

    def __init__(self, config: BacktestConfig):
        self.config = config
        self.strategy = None
        self.indicators = TechnicalIndicators()

        # State
        self.current_capital = config.initial_capital
        self.position = None  # {"side": "LONG"/"SHORT", "quantity": float, "entry_price": float}
        self.trades: List[Trade] = []
        self.equity_curve: List[Dict[str, Any]] = []
        self.drawdown_curve: List[Dict[str, Any]] = []

        # Statistics
        self.peak_capital = config.initial_capital
        self.max_drawdown = 0
        self.max_drawdown_percent = 0

    def run(self, df: pd.DataFrame) -> BacktestReport:
        """
        Run backtest on historical data

        Args:
            df: DataFrame with OHLCV data (must be sorted by date)

        Returns:
            BacktestReport with results
        """
        logger.info(f"Starting backtest for {self.config.symbol} from {self.config.start_date} to {self.config.end_date}")

        # Filter data by date range
        df = df[
            (df['timestamp'] >= self.config.start_date) &
            (df['timestamp'] <= self.config.end_date)
        ].copy()

        if df.empty:
            raise ValueError("No data available for the specified date range")

        # Sort by timestamp
        df = df.sort_values('timestamp').reset_index(drop=True)

        # Calculate indicators
        df = self.indicators.calculate_all_indicators(df)

        # Initialize strategy
        strategy_config = StrategyConfig(
            name=self.config.strategy_name,
            parameters=self.config.parameters,
            risk_settings=self.config.risk_settings
        )
        self.strategy = StrategyRegistry.get_strategy(self.config.strategy_name, strategy_config)

        if self.strategy is None:
            raise ValueError(f"Strategy '{self.config.strategy_name}' not found")

        # Run event loop
        self._run_event_loop(df)

        # Generate report
        report = self._generate_report()

        logger.info(f"Backtest completed: {report.total_trades} trades, {report.win_rate:.1%} win rate, {report.total_return:.2%} return")

        return report

    def _run_event_loop(self, df: pd.DataFrame):
        """Process each bar and generate/execute signals"""
        for i in range(len(df)):
            current_bar = df.iloc[i]
            timestamp = current_bar['timestamp']

            # Get historical data up to current bar (no lookahead)
            historical_data = df.iloc[:i+1].copy()

            # Update equity curve
            self._update_equity_curve(timestamp, current_bar['close'])

            # Generate signal
            signal = self.strategy.generate_signal(historical_data, self.config.symbol)

            # Apply slippage to signal price
            execution_price = self._apply_slippage(signal.price, signal.signal_type)

            # Execute signal
            self._execute_signal(signal, execution_price, timestamp)

        # Close any open position at the end
        if self.position is not None:
            final_bar = df.iloc[-1]
            self._close_position(final_bar['close'], final_bar['timestamp'], "End of backtest")

    def _apply_slippage(self, price: float, signal_type: SignalType) -> float:
        """Apply slippage to price"""
        if signal_type == SignalType.BUY:
            return price * (1 + self.config.slippage)
        elif signal_type == SignalType.SELL:
            return price * (1 - self.config.slippage)
        return price

    def _execute_signal(self, signal: TradingSignal, execution_price: float, timestamp: datetime):
        """Execute trading signal"""
        # Check stop loss and take profit first
        if self.position is not None:
            self._check_exit_conditions(execution_price, timestamp)

        # Process new signal
        if signal.signal_type == SignalType.BUY and self.position is None:
            self._open_position(execution_price, timestamp, "LONG")

        elif signal.signal_type == SignalType.SELL and self.position is None:
            self._open_position(execution_price, timestamp, "SHORT")

        elif signal.signal_type == SignalType.SELL and self.position is not None:
            if self.position['side'] == "LONG":
                self._close_position(execution_price, timestamp, "Signal: SELL")

    def _open_position(self, price: float, timestamp: datetime, side: str):
        """Open a new position"""
        # Calculate position size
        max_position_value = self.current_capital * self.config.risk_settings.get('max_position_size', 0.1)
        quantity = max_position_value / price

        # Apply commission
        commission = price * quantity * self.config.commission

        if commission > self.current_capital:
            logger.warning(f"Insufficient capital for commission: {commission}")
            return

        self.position = {
            'side': side,
            'quantity': quantity,
            'entry_price': price,
            'entry_date': timestamp,
        }

        logger.debug(f"Opened {side} position: {quantity} @ {price}")

    def _close_position(self, price: float, timestamp: datetime, reason: str):
        """Close existing position"""
        if self.position is None:
            return

        entry_price = self.position['entry_price']
        quantity = self.position['quantity']
        side = self.position['side']

        # Calculate P&L
        if side == "LONG":
            pnl = (price - entry_price) * quantity
        else:  # SHORT
            pnl = (entry_price - price) * quantity

        # Apply commission
        commission = price * quantity * self.config.commission
        net_pnl = pnl - commission

        # Calculate P&L percentage
        position_value = entry_price * quantity
        pnl_percent = net_pnl / position_value if position_value > 0 else 0

        # Holding period
        holding_period = (timestamp - self.position['entry_date']).days

        # Record trade
        trade = Trade(
            entry_date=self.position['entry_date'],
            exit_date=timestamp,
            symbol=self.config.symbol,
            side=side,
            entry_price=entry_price,
            exit_price=price,
            quantity=quantity,
            pnl=net_pnl,
            pnl_percent=pnl_percent,
            commission=commission,
            holding_period=holding_period,
            strategy_name=self.config.strategy_name
        )
        self.trades.append(trade)

        # Update capital
        self.current_capital += net_pnl

        logger.debug(f"Closed {side} position: {quantity} @ {price}, P&L: {net_pnl:.2f}")

        # Clear position
        self.position = None

    def _check_exit_conditions(self, current_price: float, timestamp: datetime):
        """Check stop loss and take profit conditions"""
        if self.position is None:
            return

        entry_price = self.position['entry_price']
        side = self.position['side']

        stop_loss_pct = self.config.risk_settings.get('stop_loss_pct')
        take_profit_pct = self.config.risk_settings.get('take_profit_pct')

        # Check stop loss
        if stop_loss_pct is not None:
            if side == "LONG" and current_price <= entry_price * (1 - stop_loss_pct):
                self._close_position(current_price, timestamp, "Stop Loss")
                return
            elif side == "SHORT" and current_price >= entry_price * (1 + stop_loss_pct):
                self._close_position(current_price, timestamp, "Stop Loss")
                return

        # Check take profit
        if take_profit_pct is not None:
            if side == "LONG" and current_price >= entry_price * (1 + take_profit_pct):
                self._close_position(current_price, timestamp, "Take Profit")
                return
            elif side == "SHORT" and current_price <= entry_price * (1 - take_profit_pct):
                self._close_position(current_price, timestamp, "Take Profit")
                return

    def _update_equity_curve(self, timestamp: datetime, current_price: float):
        """Update equity curve"""
        # Calculate current portfolio value
        if self.position is not None:
            position_value = self.position['quantity'] * current_price
            portfolio_value = self.current_capital + position_value
        else:
            portfolio_value = self.current_capital

        # Update peak
        if portfolio_value > self.peak_capital:
            self.peak_capital = portfolio_value

        # Calculate drawdown
        drawdown = self.peak_capital - portfolio_value
        drawdown_percent = drawdown / self.peak_capital if self.peak_capital > 0 else 0

        # Update max drawdown
        if drawdown > self.max_drawdown:
            self.max_drawdown = drawdown
            self.max_drawdown_percent = drawdown_percent

        # Record equity point
        self.equity_curve.append({
            'timestamp': timestamp.isoformat(),
            'capital': portfolio_value,
            'drawdown': drawdown,
            'drawdown_percent': drawdown_percent,
        })

    def _generate_report(self) -> BacktestReport:
        """Generate backtest report"""
        final_capital = self.current_capital

        # Calculate returns
        total_return = (final_capital - self.config.initial_capital) / self.config.initial_capital

        # Calculate CAGR
        days = (self.equity_curve[-1]['timestamp'] if self.equity_curve else self.config.end_date - self.config.start_date)
        if isinstance(days, str):
            days = (datetime.fromisoformat(days) - self.config.start_date).days
        years = max(days / 365, 1)
        cagr = (final_capital / self.config.initial_capital) ** (1 / years) - 1

        # Trade statistics
        total_trades = len(self.trades)
        profitable_trades = sum(1 for t in self.trades if t.pnl > 0)
        losing_trades = sum(1 for t in self.trades if t.pnl <= 0)
        win_rate = profitable_trades / total_trades if total_trades > 0 else 0

        # Profit factor
        gross_profit = sum(t.pnl for t in self.trades if t.pnl > 0)
        gross_loss = abs(sum(t.pnl for t in self.trades if t.pnl < 0))
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else 0

        # Average win/loss
        winning_trades = [t.pnl for t in self.trades if t.pnl > 0]
        losing_trades_list = [t.pnl for t in self.trades if t.pnl < 0]
        avg_win = np.mean(winning_trades) if winning_trades else 0
        avg_loss = np.mean(losing_trades_list) if losing_trades_list else 0

        # Average holding period
        avg_holding_period = np.mean([t.holding_period for t in self.trades]) if self.trades else 0

        # Largest win/loss
        largest_win = max(winning_trades) if winning_trades else 0
        largest_loss = min(losing_trades_list) if losing_trades_list else 0

        # Calculate Sharpe and Sortino ratios
        returns = []
        if len(self.equity_curve) > 1:
            for i in range(1, len(self.equity_curve)):
                prev_capital = self.equity_curve[i-1]['capital']
                curr_capital = self.equity_curve[i]['capital']
                if prev_capital > 0:
                    returns.append((curr_capital - prev_capital) / prev_capital)

        if returns:
            returns = np.array(returns)
            sharpe_ratio = np.mean(returns) / np.std(returns) * np.sqrt(252) if np.std(returns) > 0 else None

            # Sortino uses downside deviation
            downside_returns = returns[returns < 0]
            downside_deviation = np.std(downside_returns) if len(downside_returns) > 0 else 0
            sortino_ratio = np.mean(returns) / downside_deviation * np.sqrt(252) if downside_deviation > 0 else None
        else:
            sharpe_ratio = None
            sortino_ratio = None

        return BacktestReport(
            strategy_name=self.config.strategy_name,
            symbol=self.config.symbol,
            start_date=self.config.start_date,
            end_date=self.config.end_date,
            initial_capital=self.config.initial_capital,
            final_capital=final_capital,
            total_return=total_return,
            cagr=cagr,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            max_drawdown=self.max_drawdown,
            max_drawdown_percent=self.max_drawdown_percent,
            total_trades=total_trades,
            profitable_trades=profitable_trades,
            losing_trades=losing_trades,
            win_rate=win_rate,
            profit_factor=profit_factor,
            avg_win=avg_win,
            avg_loss=avg_loss,
            avg_holding_period=avg_holding_period,
            largest_win=largest_win,
            largest_loss=largest_loss,
            equity_curve=self.equity_curve,
            trades=[{
                'entry_date': t.entry_date.isoformat(),
                'exit_date': t.exit_date.isoformat(),
                'side': t.side,
                'entry_price': t.entry_price,
                'exit_price': t.exit_price,
                'quantity': t.quantity,
                'pnl': t.pnl,
                'pnl_percent': t.pnl_percent,
            } for t in self.trades],
        )
