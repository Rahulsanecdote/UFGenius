"""
Risk Management System
Position sizing, exposure limits, drawdown controls, and kill switch
"""
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


@dataclass
class RiskLimits:
    """Risk management limits"""
    max_position_size: float = 0.1      # 10% of portfolio
    max_daily_loss: float = 0.05         # 5% daily loss limit
    max_drawdown: float = 0.15           # 15% max drawdown
    max_open_positions: int = 5          # Max concurrent positions
    max_exposure_per_asset: float = 0.2   # Max 20% in single asset
    kill_switch_enabled: bool = True


@dataclass
class RiskMetrics:
    """Current risk metrics"""
    current_capital: float
    daily_pnl: float
    daily_pnl_percent: float
    current_drawdown: float
    current_drawdown_percent: float
    open_positions_count: int
    portfolio_exposure: float


class RiskManager:
    """
    Risk management system for trading
    Enforces position sizing, exposure limits, and emergency stop controls
    """

    def __init__(self, initial_capital: float, limits: Optional[RiskLimits] = None):
        self.initial_capital = initial_capital
        self.current_capital = initial_capital
        self.peak_capital = initial_capital
        self.limits = limits or RiskLimits()

        # State
        self.kill_switch_engaged = False
        self.daily_loss_limit_triggered = False
        self.max_drawdown_triggered = False

        # Daily tracking
        self.daily_start_capital = initial_capital
        self.today_trades: List[Dict[str, Any]] = []
        self.last_reset_date = datetime.utcnow().date()

        # Position tracking
        self.open_positions: Dict[str, Dict[str, Any]] = {}

    def calculate_position_size(
        self,
        price: float,
        stop_loss_pct: Optional[float] = None
    ) -> float:
        """
        Calculate position size based on risk management rules

        Args:
            price: Entry price
            stop_loss_pct: Optional stop loss percentage for risk-based sizing

        Returns:
            Position size (quantity)
        """
        # Check kill switch
        if self.kill_switch_engaged:
            logger.warning("Kill switch engaged - position size = 0")
            return 0

        # Check daily loss limit
        if self.daily_loss_limit_triggered:
            logger.warning("Daily loss limit triggered - position size = 0")
            return 0

        # Check max drawdown
        if self.max_drawdown_triggered:
            logger.warning("Max drawdown triggered - position size = 0")
            return 0

        # Base position size (percentage of capital)
        max_position_value = self.current_capital * self.limits.max_position_size

        # If stop loss provided, use risk-based position sizing (Kelly-inspired)
        if stop_loss_pct and stop_loss_pct > 0:
            risk_amount = self.current_capital * 0.02  # 2% risk per trade
            position_value = min(risk_amount / stop_loss_pct, max_position_value)
        else:
            position_value = max_position_value

        # Calculate quantity
        quantity = position_value / price

        return quantity

    def can_open_position(
        self,
        symbol: str,
        quantity: float,
        price: float
    ) -> tuple[bool, str]:
        """
        Check if a new position can be opened

        Args:
            symbol: Trading symbol
            quantity: Position quantity
            price: Entry price

        Returns:
            (allowed, reason)
        """
        # Check kill switch
        if self.kill_switch_engaged:
            return False, "Kill switch engaged"

        # Check daily loss limit
        if self.daily_loss_limit_triggered:
            return False, "Daily loss limit reached"

        # Check max drawdown
        if self.max_drawdown_triggered:
            return False, "Maximum drawdown limit reached"

        # Check max open positions
        if len(self.open_positions) >= self.limits.max_open_positions:
            return False, f"Maximum open positions ({self.limits.max_open_positions}) reached"

        # Check position value
        position_value = quantity * price
        position_percent = position_value / self.current_capital

        if position_percent > self.limits.max_position_size:
            return False, f"Position size ({position_percent:.1%}) exceeds limit ({self.limits.max_position_size:.1%})"

        # Check asset exposure
        current_exposure = sum(
            pos['quantity'] * pos.get('current_price', pos['entry_price'])
            for sym, pos in self.open_positions.items()
            if sym == symbol
        )
        total_exposure = position_value + current_exposure

        if total_exposure / self.current_capital > self.limits.max_exposure_per_asset:
            return False, f"Asset exposure limit exceeded for {symbol}"

        return True, "Position allowed"

    def open_position(
        self,
        symbol: str,
        side: str,
        quantity: float,
        entry_price: float,
        strategy_name: str
    ) -> Optional[Dict[str, Any]]:
        """
        Record opening of a new position
        """
        can_open, reason = self.can_open_position(symbol, quantity, entry_price)

        if not can_open:
            logger.warning(f"Cannot open position: {reason}")
            return None

        position = {
            'symbol': symbol,
            'side': side,
            'quantity': quantity,
            'entry_price': entry_price,
            'current_price': entry_price,
            'unrealized_pnl': 0,
            'strategy_name': strategy_name,
            'opened_at': datetime.utcnow(),
        }

        self.open_positions[symbol] = position
        logger.info(f"Opened {side} position: {symbol} {quantity} @ {entry_price}")

        return position

    def close_position(
        self,
        symbol: str,
        exit_price: float,
        reason: str = "Signal"
    ) -> Optional[Dict[str, Any]]:
        """
        Record closing of a position
        """
        if symbol not in self.open_positions:
            logger.warning(f"Position not found: {symbol}")
            return None

        position = self.open_positions[symbol]

        # Calculate P&L
        if position['side'] == 'LONG':
            pnl = (exit_price - position['entry_price']) * position['quantity']
        else:  # SHORT
            pnl = (position['entry_price'] - exit_price) * position['quantity']

        # Apply commission (estimate)
        commission = exit_price * position['quantity'] * 0.001
        net_pnl = pnl - commission

        # Update capital
        self.current_capital += net_pnl

        # Update peak capital
        if self.current_capital > self.peak_capital:
            self.peak_capital = self.current_capital

        # Record trade
        trade_record = {
            'symbol': symbol,
            'side': position['side'],
            'entry_price': position['entry_price'],
            'exit_price': exit_price,
            'quantity': position['quantity'],
            'pnl': net_pnl,
            'reason': reason,
            'closed_at': datetime.utcnow(),
        }
        self.today_trades.append(trade_record)

        # Remove position
        del self.open_positions[symbol]

        # Check risk limits after trade
        self._check_risk_limits()

        logger.info(f"Closed {position['side']} position: {symbol} @ {exit_price}, P&L: {net_pnl:.2f}")

        return trade_record

    def update_position_price(self, symbol: str, current_price: float):
        """Update position with current market price"""
        if symbol in self.open_positions:
            position = self.open_positions[symbol]
            position['current_price'] = current_price

            # Calculate unrealized P&L
            if position['side'] == 'LONG':
                pnl = (current_price - position['entry_price']) * position['quantity']
            else:
                pnl = (position['entry_price'] - current_price) * position['quantity']

            position['unrealized_pnl'] = pnl

    def get_risk_metrics(self) -> RiskMetrics:
        """Get current risk metrics"""
        # Calculate daily P&L
        daily_pnl = self.current_capital - self.daily_start_capital
        daily_pnl_percent = daily_pnl / self.daily_start_capital if self.daily_start_capital > 0 else 0

        # Calculate drawdown
        drawdown = self.peak_capital - self.current_capital
        drawdown_percent = drawdown / self.peak_capital if self.peak_capital > 0 else 0

        # Calculate portfolio exposure
        total_exposure = sum(
            pos['quantity'] * pos.get('current_price', pos['entry_price'])
            for pos in self.open_positions.values()
        )
        portfolio_exposure = total_exposure / self.current_capital if self.current_capital > 0 else 0

        return RiskMetrics(
            current_capital=self.current_capital,
            daily_pnl=daily_pnl,
            daily_pnl_percent=daily_pnl_percent,
            current_drawdown=drawdown,
            current_drawdown_percent=drawdown_percent,
            open_positions_count=len(self.open_positions),
            portfolio_exposure=portfolio_exposure,
        )

    def _check_risk_limits(self):
        """Check and update risk limits"""
        metrics = self.get_risk_metrics()

        # Check daily loss limit
        if metrics.daily_pnl_percent <= -self.limits.max_daily_loss:
            self.daily_loss_limit_triggered = True
            logger.warning(f"Daily loss limit triggered: {metrics.daily_pnl_percent:.2%}")

        # Check max drawdown
        if metrics.current_drawdown_percent >= self.limits.max_drawdown:
            self.max_drawdown_triggered = True
            logger.warning(f"Max drawdown triggered: {metrics.current_drawdown_percent:.2%}")

    def reset_daily_limits(self):
        """Reset daily risk limits (call at start of trading day)"""
        today = datetime.utcnow().date()

        if today > self.last_reset_date:
            self.daily_start_capital = self.current_capital
            self.today_trades = []
            self.daily_loss_limit_triggered = False
            self.last_reset_date = today
            logger.info("Daily risk limits reset")

    def engage_kill_switch(self, reason: str = "Manual"):
        """Engage kill switch to stop all trading"""
        self.kill_switch_engaged = True
        logger.critical(f"KILL SWITCH ENGAGED: {reason}")

    def disengage_kill_switch(self):
        """Disengage kill switch"""
        self.kill_switch_engaged = False
        logger.info("Kill switch disengaged")

    def get_status(self) -> Dict[str, Any]:
        """Get risk manager status"""
        metrics = self.get_risk_metrics()

        return {
            'kill_switch_engaged': self.kill_switch_engaged,
            'daily_loss_limit_triggered': self.daily_loss_limit_triggered,
            'max_drawdown_triggered': self.max_drawdown_triggered,
            'current_capital': self.current_capital,
            'peak_capital': self.peak_capital,
            'daily_pnl': metrics.daily_pnl,
            'daily_pnl_percent': metrics.daily_pnl_percent,
            'drawdown': metrics.current_drawdown,
            'drawdown_percent': metrics.current_drawdown_percent,
            'open_positions': len(self.open_positions),
            'portfolio_exposure': metrics.portfolio_exposure,
            'limits': {
                'max_position_size': self.limits.max_position_size,
                'max_daily_loss': self.limits.max_daily_loss,
                'max_drawdown': self.limits.max_drawdown,
                'max_open_positions': self.limits.max_open_positions,
            }
        }
