"""
Market Data Service
Fetching and providing market data
"""
import pandas as pd
import numpy as np
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class MarketDataService:
    """
    Market data provider with sample data generation for testing
    In production, this would connect to real market data APIs
    """

    def __init__(self):
        self.cache: Dict[str, pd.DataFrame] = {}

    async def get_historical_data(
        self,
        symbol: str,
        start_date: datetime,
        end_date: datetime,
        interval: str = "1d"
    ) -> pd.DataFrame:
        """
        Get historical OHLCV data for a symbol

        Args:
            symbol: Stock symbol
            start_date: Start date
            end_date: End date
            interval: Data interval (1d, 1h, etc.)

        Returns:
            DataFrame with OHLCV data
        """
        # Check cache
        cache_key = f"{symbol}_{interval}"
        if cache_key in self.cache:
            df = self.cache[cache_key]
            return df[
                (df['timestamp'] >= start_date) &
                (df['timestamp'] <= end_date)
            ].copy()

        # Generate sample data for demonstration
        # In production, replace with real API calls
        df = self._generate_sample_data(symbol, start_date, end_date, interval)
        self.cache[cache_key] = df

        return df

    def _generate_sample_data(
        self,
        symbol: str,
        start_date: datetime,
        end_date: datetime,
        interval: str
    ) -> pd.DataFrame:
        """Generate sample market data for testing"""
        # Determine number of periods
        if interval == "1d":
            periods = (end_date - start_date).days
            freq = "D"
        elif interval == "1h":
            periods = int((end_date - start_date).total_seconds() / 3600)
            freq = "H"
        else:
            periods = (end_date - start_date).days * 24
            freq = "H"

        periods = max(periods, 100)  # Minimum 100 periods

        # Generate dates
        dates = pd.date_range(start=start_date, periods=periods, freq=freq)

        # Generate realistic price movement using random walk
        np.random.seed(hash(symbol) % 2**32)  # Consistent per symbol

        # Initial price based on symbol
        base_prices = {
            'AAPL': 150.0,
            'GOOGL': 140.0,
            'MSFT': 380.0,
            'AMZN': 175.0,
            'TSLA': 250.0,
            'SPY': 450.0,
            'QQQ': 380.0,
        }
        initial_price = base_prices.get(symbol, 100.0)

        # Generate returns with some trend and volatility
        daily_return = 0.0005  # Slight upward bias
        volatility = 0.02

        returns = np.random.normal(daily_return, volatility, periods)
        prices = initial_price * np.cumprod(1 + returns)

        # Generate OHLCV data
        data = []
        for i, (date, close) in enumerate(zip(dates, prices)):
            # Generate high/low with some noise
            daily_range = close * np.random.uniform(0.005, 0.03)
            high = close + np.random.uniform(0, daily_range)
            low = close - np.random.uniform(0, daily_range)

            # Open is previous close or slight gap
            if i == 0:
                open_price = close * (1 + np.random.uniform(-0.01, 0.01))
            else:
                open_price = prices[i-1]

            # Ensure OHLC consistency
            high = max(high, open_price, close)
            low = min(low, open_price, close)

            # Volume
            volume = np.random.randint(1_000_000, 10_000_000)

            data.append({
                'timestamp': date,
                'symbol': symbol,
                'open': round(open_price, 2),
                'high': round(high, 2),
                'low': round(low, 2),
                'close': round(close, 2),
                'volume': volume,
            })

        df = pd.DataFrame(data)
        df['timestamp'] = pd.to_datetime(df['timestamp'])

        return df

    async def get_latest_price(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get latest price for a symbol"""
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=5)

        df = await self.get_historical_data(symbol, start_date, end_date, "1d")

        if df.empty:
            return None

        latest = df.iloc[-1]
        prev = df.iloc[-2] if len(df) > 1 else latest

        change = latest['close'] - prev['close']
        change_percent = (change / prev['close']) * 100 if prev['close'] > 0 else 0

        return {
            'symbol': symbol,
            'price': float(latest['close']),
            'open': float(latest['open']),
            'high': float(latest['high']),
            'low': float(latest['low']),
            'volume': int(latest['volume']),
            'change': float(change),
            'change_percent': float(change_percent),
            'timestamp': latest['timestamp'].isoformat(),
        }

    async def get_multiple_prices(self, symbols: List[str]) -> Dict[str, Dict[str, Any]]:
        """Get latest prices for multiple symbols"""
        results = {}
        for symbol in symbols:
            try:
                price_data = await self.get_latest_price(symbol)
                if price_data:
                    results[symbol] = price_data
            except Exception as e:
                logger.error(f"Error fetching price for {symbol}: {e}")

        return results

    def clear_cache(self):
        """Clear cached data"""
        self.cache.clear()
        logger.info("Market data cache cleared")


# Singleton instance
market_data_service = MarketDataService()
