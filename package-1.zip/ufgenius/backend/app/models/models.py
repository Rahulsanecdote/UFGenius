"""
Database Models
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, JSON, Text, Enum as SQLEnum
from sqlalchemy.sql import func
import enum

from app.core.database import Base


class SignalType(str, enum.Enum):
    """Trading signal types"""
    BUY = "BUY"
    SELL = "SELL"
    HOLD = "HOLD"


class OrderType(str, enum.Enum):
    """Order types"""
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"
    STOP_LIMIT = "STOP_LIMIT"


class OrderStatus(str, enum.Enum):
    """Order status"""
    PENDING = "PENDING"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"


class Position(Base):
    """Trading position model"""
    __tablename__ = "positions"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String(20), nullable=False, index=True)
    quantity = Column(Float, nullable=False, default=0)
    entry_price = Column(Float, nullable=True)
    current_price = Column(Float, nullable=True)
    unrealized_pnl = Column(Float, nullable=True, default=0)
    realized_pnl = Column(Float, nullable=True, default=0)
    side = Column(String(10), nullable=False)  # LONG or SHORT
    status = Column(String(20), nullable=False, default="OPEN")
    opened_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    closed_at = Column(DateTime, nullable=True)
    strategy_name = Column(String(100), nullable=True)
    metadata = Column(JSON, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class Order(Base):
    """Order model"""
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String(20), nullable=False, index=True)
    order_type = Column(SQLEnum(OrderType), nullable=False)
    side = Column(String(10), nullable=False)  # BUY or SELL
    quantity = Column(Float, nullable=False)
    price = Column(Float, nullable=True)
    status = Column(SQLEnum(OrderStatus), nullable=False, default=OrderStatus.PENDING)
    filled_price = Column(Float, nullable=True)
    filled_quantity = Column(Float, nullable=True)
    filled_at = Column(DateTime, nullable=True)
    strategy_name = Column(String(100), nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class TradeSignal(Base):
    """Trading signal model"""
    __tablename__ = "trade_signals"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String(20), nullable=False, index=True)
    signal_type = Column(SQLEnum(SignalType), nullable=False)
    strength = Column(Float, nullable=True)  # 0-1 confidence
    price = Column(Float, nullable=False)
    indicators = Column(JSON, nullable=True)  # Indicator values at signal time
    strategy_name = Column(String(100), nullable=False, index=True)
    executed = Column(Boolean, nullable=False, default=False)
    execution_price = Column(Float, nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())


class BacktestResult(Base):
    """Backtest result model"""
    __tablename__ = "backtest_results"

    id = Column(Integer, primary_key=True, index=True)
    strategy_name = Column(String(100), nullable=False, index=True)
    symbol = Column(String(20), nullable=False)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=False)
    initial_capital = Column(Float, nullable=False)
    final_capital = Column(Float, nullable=False)
    total_return = Column(Float, nullable=False)
    cagr = Column(Float, nullable=False)
    sharpe_ratio = Column(Float, nullable=True)
    sortino_ratio = Column(Float, nullable=True)
    max_drawdown = Column(Float, nullable=False)
    win_rate = Column(Float, nullable=True)
    total_trades = Column(Integer, nullable=False)
    profitable_trades = Column(Integer, nullable=False)
    losing_trades = Column(Integer, nullable=False)
    parameters = Column(JSON, nullable=True)
    equity_curve = Column(JSON, nullable=True)
    trades = Column(JSON, nullable=True)
    created_at = Column(DateTime, server_default=func.now())


class MarketData(Base):
    """Market OHLCV data model"""
    __tablename__ = "market_data"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String(20), nullable=False, index=True)
    timestamp = Column(DateTime, nullable=False, index=True)
    open = Column(Float, nullable=False)
    high = Column(Float, nullable=False)
    low = Column(Float, nullable=False)
    close = Column(Float, nullable=False)
    volume = Column(Float, nullable=False)
    created_at = Column(DateTime, server_default=func.now())

    __table_args__ = (
        {"sqlite_autoincrement": True},
    )


class Watchlist(Base):
    """Watchlist model"""
    __tablename__ = "watchlists"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String(20), nullable=False, unique=True, index=True)
    name = Column(String(100), nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())


class StrategyConfig(Base):
    """Strategy configuration model"""
    __tablename__ = "strategy_configs"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, unique=True, index=True)
    is_active = Column(Boolean, nullable=False, default=False)
    parameters = Column(JSON, nullable=False)
    risk_settings = Column(JSON, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class SystemStatus(Base):
    """System status model"""
    __tablename__ = "system_status"

    id = Column(Integer, primary_key=True, index=True)
    component = Column(String(100), nullable=False, unique=True)
    status = Column(String(20), nullable=False)  # RUNNING, STOPPED, ERROR
    message = Column(Text, nullable=True)
    last_heartbeat = Column(DateTime, nullable=False, default=datetime.utcnow)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
