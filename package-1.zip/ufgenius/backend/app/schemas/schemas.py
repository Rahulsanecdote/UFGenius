"""
Pydantic Schemas for API Request/Response
"""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, ConfigDict


# Base schemas
class TimestampMixin(BaseModel):
    """Timestamp mixin"""
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


# Market Data schemas
class OHLCVBase(BaseModel):
    """OHLCV data base"""
    symbol: str = Field(..., description="Stock symbol")
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float


class OHLCVResponse(OHLCVBase):
    """OHLCV data response"""
    id: int

    model_config = ConfigDict(from_attributes=True)


class MarketDataResponse(BaseModel):
    """Market data response"""
    symbol: str
    price: float
    change: float
    change_percent: float
    volume: int
    timestamp: datetime


class WatchlistCreate(BaseModel):
    """Watchlist create schema"""
    symbol: str = Field(..., description="Stock symbol")
    name: Optional[str] = Field(None, description="Display name")
    notes: Optional[str] = Field(None, description="Notes")


class WatchlistResponse(WatchlistCreate, TimestampMixin):
    """Watchlist response"""
    id: int
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


# Position schemas
class PositionResponse(BaseModel):
    """Position response"""
    id: int
    symbol: str
    quantity: float
    entry_price: Optional[float]
    current_price: Optional[float]
    unrealized_pnl: Optional[float]
    realized_pnl: Optional[float]
    side: str
    status: str
    opened_at: datetime
    closed_at: Optional[datetime]
    strategy_name: Optional[str]

    model_config = ConfigDict(from_attributes=True)


# Order schemas
class OrderCreate(BaseModel):
    """Order create schema"""
    symbol: str
    order_type: str = "MARKET"
    side: str  # BUY or SELL
    quantity: float
    price: Optional[float] = None
    strategy_name: Optional[str] = None
    notes: Optional[str] = None


class OrderResponse(OrderCreate):
    """Order response"""
    id: int
    status: str
    filled_price: Optional[float]
    filled_quantity: Optional[float]
    filled_at: Optional[datetime]
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Signal schemas
class SignalResponse(BaseModel):
    """Signal response"""
    id: int
    symbol: str
    signal_type: str
    strength: Optional[float]
    price: float
    indicators: Optional[Dict[str, Any]]
    strategy_name: str
    executed: bool
    execution_price: Optional[float]
    notes: Optional[str]
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class SignalCreate(BaseModel):
    """Signal create schema"""
    symbol: str
    signal_type: str
    strength: Optional[float] = None
    price: float
    indicators: Optional[Dict[str, Any]] = None
    strategy_name: str
    notes: Optional[str] = None


# Strategy schemas
class StrategyParameter(BaseModel):
    """Strategy parameter"""
    name: str
    value: Any
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    description: Optional[str] = None


class RiskSettings(BaseModel):
    """Risk management settings"""
    max_position_size: float = Field(0.1, description="Max position size as % of portfolio")
    max_daily_loss: float = Field(0.05, description="Max daily loss as %")
    max_drawdown: float = Field(0.15, description="Max drawdown as %")
    stop_loss_pct: Optional[float] = Field(None, description="Stop loss percentage")
    take_profit_pct: Optional[float] = Field(None, description="Take profit percentage")
    kill_switch_enabled: bool = Field(True, description="Enable kill switch")


class StrategyConfigCreate(BaseModel):
    """Strategy config create schema"""
    name: str = Field(..., description="Strategy name")
    is_active: bool = Field(False, description="Is strategy active")
    parameters: Dict[str, Any] = Field(..., description="Strategy parameters")
    risk_settings: Optional[RiskSettings] = None


class StrategyConfigResponse(StrategyConfigCreate, TimestampMixin):
    """Strategy config response"""
    id: int

    model_config = ConfigDict(from_attributes=True)


# Backtest schemas
class BacktestParameters(BaseModel):
    """Backtest parameters"""
    strategy_name: str
    symbol: str
    start_date: datetime
    end_date: datetime
    initial_capital: float = Field(100000, description="Initial capital")
    commission: float = Field(0.001, description="Commission rate")
    slippage: float = Field(0.001, description="Slippage rate")
    parameters: Optional[Dict[str, Any]] = None


class BacktestResultResponse(BaseModel):
    """Backtest result response"""
    id: int
    strategy_name: str
    symbol: str
    start_date: datetime
    end_date: datetime
    initial_capital: float
    final_capital: float
    total_return: float
    cagr: float
    sharpe_ratio: Optional[float]
    sortino_ratio: Optional[float]
    max_drawdown: float
    win_rate: Optional[float]
    total_trades: int
    profitable_trades: int
    losing_trades: int
    parameters: Optional[Dict[str, Any]]
    equity_curve: Optional[List[Dict[str, Any]]]
    trades: Optional[List[Dict[str, Any]]]
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class BacktestMetrics(BaseModel):
    """Backtest metrics summary"""
    total_return: float
    cagr: float
    sharpe_ratio: Optional[float]
    sortino_ratio: Optional[float]
    max_drawdown: float
    win_rate: Optional[float]
    profit_factor: Optional[float]
    avg_win: Optional[float]
    avg_loss: Optional[float]
    total_trades: int
    profitable_trades: int
    losing_trades: int


# Indicator schemas
class IndicatorValue(BaseModel):
    """Indicator value"""
    name: str
    value: float
    timestamp: datetime


class IndicatorSet(BaseModel):
    """Complete indicator set for a symbol"""
    symbol: str
    timestamp: datetime
    rsi: Optional[float] = None
    macd: Optional[Dict[str, float]] = None  # {macd, signal, histogram}
    bollinger_bands: Optional[Dict[str, float]] = None  # {upper, middle, lower}
    sma: Optional[Dict[str, float]] = None  # {sma_20, sma_50, sma_200}
    ema: Optional[Dict[str, float]] = None  # {ema_12, ema_26}
    atr: Optional[float] = None


# System schemas
class SystemStatusResponse(BaseModel):
    """System status response"""
    component: str
    status: str
    message: Optional[str]
    last_heartbeat: datetime

    model_config = ConfigDict(from_attributes=True)


class HealthCheckResponse(BaseModel):
    """Health check response"""
    status: str
    database: str
    websocket: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
