# Universal Financial Genius - Backend

## Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Running

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Environment Variables

Create `.env` file:

```
DATABASE_URL=postgresql://user:password@localhost:5432/ufgenius
REDIS_URL=redis://localhost:6379
API_KEY=your_api_key_here
LOG_LEVEL=INFO
```

## API Documentation

Once running, visit: http://localhost:8000/docs
