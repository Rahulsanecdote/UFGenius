/**
 * Backtest Form Component
 */
import { useState } from 'react';
import { Play, Settings, Clock, DollarSign } from 'lucide-react';
import { Strategy } from '../lib/store';

interface BacktestFormProps {
  strategies: Strategy[];
  selectedStrategy: string;
  onStrategyChange: (strategy: string) => void;
  onRunBacktest: (params: {
    strategy_name: string;
    symbol: string;
    start_date: string;
    end_date: string;
    initial_capital: number;
    commission: number;
    slippage: number;
  }) => void;
  isRunning: boolean;
}

export function BacktestForm({
  strategies,
  selectedStrategy,
  onStrategyChange,
  onRunBacktest,
  isRunning,
}: BacktestFormProps) {
  const [symbol, setSymbol] = useState('AAPL');
  const [startDate, setStartDate] = useState(() => {
    const date = new Date();
    date.setFullYear(date.getFullYear() - 1);
    return date.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [initialCapital, setInitialCapital] = useState(100000);
  const [commission, setCommission] = useState(0.001);
  const [slippage, setSlippage] = useState(0.001);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onRunBacktest({
      strategy_name: selectedStrategy,
      symbol,
      start_date: startDate,
      end_date: endDate,
      initial_capital: initialCapital,
      commission,
      slippage,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="bg-slate-800 rounded-lg border border-slate-700 p-6 space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Settings className="w-5 h-5 text-blue-400" />
        <h3 className="text-white font-semibold">Backtest Configuration</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Strategy Selection */}
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">Strategy</label>
          <select
            value={selectedStrategy}
            onChange={(e) => onStrategyChange(e.target.value)}
            className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {strategies.map((strategy) => (
              <option key={strategy.name} value={strategy.name}>
                {strategy.name.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase())}
              </option>
            ))}
          </select>
        </div>

        {/* Symbol */}
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">Symbol</label>
          <input
            type="text"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="AAPL"
          />
        </div>

        {/* Start Date */}
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">
            <Clock className="w-4 h-4 inline mr-1" />
            Start Date
          </label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* End Date */}
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">
            <Clock className="w-4 h-4 inline mr-1" />
            End Date
          </label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Initial Capital */}
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">
            <DollarSign className="w-4 h-4 inline mr-1" />
            Initial Capital
          </label>
          <input
            type="number"
            value={initialCapital}
            onChange={(e) => setInitialCapital(Number(e.target.value))}
            className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            min={1000}
            step={1000}
          />
        </div>

        {/* Commission */}
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">Commission (%)</label>
          <input
            type="number"
            value={commission * 100}
            onChange={(e) => setCommission(Number(e.target.value) / 100)}
            className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            min={0}
            max={1}
            step={0.01}
          />
        </div>

        {/* Slippage */}
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">Slippage (%)</label>
          <input
            type="number"
            value={slippage * 100}
            onChange={(e) => setSlippage(Number(e.target.value) / 100)}
            className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            min={0}
            max={1}
            step={0.01}
          />
        </div>
      </div>

      {/* Submit Button */}
      <button
        type="submit"
        disabled={isRunning}
        className={`w-full flex items-center justify-center gap-2 py-3 rounded-lg font-semibold transition-colors ${
          isRunning
            ? 'bg-slate-600 text-slate-400 cursor-not-allowed'
            : 'bg-blue-600 hover:bg-blue-700 text-white'
        }`}
      >
        <Play className={`w-5 h-5 ${isRunning ? 'animate-spin' : ''}`} />
        {isRunning ? 'Running Backtest...' : 'Run Backtest'}
      </button>
    </form>
  );
}
