/**
 * Signal Card Component
 */
import { ArrowUp, ArrowDown, Minus, Signal } from 'lucide-react';
import { Signal as SignalType } from '../lib/store';

interface SignalCardProps {
  signal: SignalType;
}

export function SignalCard({ signal }: SignalCardProps) {
  const getSignalColor = () => {
    switch (signal.signal_type) {
      case 'BUY':
        return 'bg-emerald-500/20 border-emerald-500 text-emerald-400';
      case 'SELL':
        return 'bg-red-500/20 border-red-500 text-red-400';
      default:
        return 'bg-slate-700 border-slate-600 text-slate-400';
    }
  };

  const getSignalIcon = () => {
    switch (signal.signal_type) {
      case 'BUY':
        return <ArrowUp className="w-5 h-5" />;
      case 'SELL':
        return <ArrowDown className="w-5 h-5" />;
      default:
        return <Minus className="w-5 h-5" />;
    }
  };

  return (
    <div className={`p-4 rounded-lg border ${getSignalColor()}`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          {getSignalIcon()}
          <span className="font-semibold">{signal.signal_type}</span>
        </div>
        <span className="text-sm opacity-75">{signal.strategy_name}</span>
      </div>
      <div className="text-sm opacity-75 mb-2">{signal.message}</div>
      <div className="flex items-center justify-between text-sm">
        <span>Price: ${signal.price.toFixed(2)}</span>
        {signal.strength > 0 && (
          <span>Strength: {(signal.strength * 100).toFixed(0)}%</span>
        )}
      </div>
    </div>
  );
}

interface SignalsListProps {
  signals: SignalType[];
}

export function SignalsList({ signals }: SignalsListProps) {
  if (signals.length === 0) {
    return (
      <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
        <div className="flex items-center gap-2 mb-4">
          <Signal className="w-5 h-5 text-blue-400" />
          <h3 className="text-white font-semibold">Trading Signals</h3>
        </div>
        <div className="text-slate-500 text-center py-8">
          No signals available. Select a symbol to view signals.
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
      <div className="flex items-center gap-2 mb-4">
        <Signal className="w-5 h-5 text-blue-400" />
        <h3 className="text-white font-semibold">Trading Signals</h3>
      </div>
      <div className="space-y-3">
        {signals.map((signal, index) => (
          <SignalCard key={`${signal.strategy_name}-${index}`} signal={signal} />
        ))}
      </div>
    </div>
  );
}
