/**
 * Risk Status Component
 */
import { Shield, AlertTriangle, TrendingDown, Power, PowerOff } from 'lucide-react';
import { RiskStatus as RiskStatusType } from '../lib/store';

interface RiskStatusProps {
  status: RiskStatusType;
  onToggleKillSwitch: (engage: boolean) => void;
}

export function RiskStatus({ status, onToggleKillSwitch }: RiskStatusProps) {
  const isAtRisk = status.daily_loss_limit_triggered || status.max_drawdown_triggered;

  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-blue-400" />
          <h3 className="text-white font-semibold">Risk Management</h3>
        </div>

        {/* Kill Switch Button */}
        <button
          onClick={() => onToggleKillSwitch(!status.kill_switch_engaged)}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
            status.kill_switch_engaged
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : 'bg-slate-700 hover:bg-slate-600 text-white'
          }`}
        >
          {status.kill_switch_engaged ? (
            <>
              <PowerOff className="w-4 h-4" />
              KILL SWITCH ACTIVE
            </>
          ) : (
            <>
              <Power className="w-4 h-4" />
              Engage Kill Switch
            </>
          )}
        </button>
      </div>

      {/* Status Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-700/50 rounded-lg p-3">
          <div className="text-sm text-slate-400 mb-1">Current Capital</div>
          <div className="text-lg font-bold text-white">
            ${status.current_capital.toLocaleString()}
          </div>
        </div>

        <div className="bg-slate-700/50 rounded-lg p-3">
          <div className="text-sm text-slate-400 mb-1">Daily P&L</div>
          <div className={`text-lg font-bold ${status.daily_pnl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {status.daily_pnl >= 0 ? '+' : ''}${status.daily_pnl.toFixed(2)}
            <span className="text-sm ml-1">({(status.daily_pnl_percent * 100).toFixed(2)}%)</span>
          </div>
        </div>

        <div className="bg-slate-700/50 rounded-lg p-3">
          <div className="text-sm text-slate-400 mb-1">Drawdown</div>
          <div className={`text-lg font-bold ${status.drawdown_percent > 0.1 ? 'text-red-400' : 'text-white'}`}>
            ${status.drawdown.toFixed(2)}
            <span className="text-sm ml-1">({(status.drawdown_percent * 100).toFixed(2)}%)</span>
          </div>
        </div>

        <div className="bg-slate-700/50 rounded-lg p-3">
          <div className="text-sm text-slate-400 mb-1">Open Positions</div>
          <div className="text-lg font-bold text-white">
            {status.open_positions}
            <span className="text-sm text-slate-400 ml-1">/ 5</span>
          </div>
        </div>
      </div>

      {/* Risk Alerts */}
      {(status.daily_loss_limit_triggered || status.max_drawdown_triggered || status.kill_switch_engaged) && (
        <div className="space-y-2">
          {status.kill_switch_engaged && (
            <div className="flex items-center gap-2 p-3 bg-red-500/20 border border-red-500 rounded-lg text-red-400">
              <AlertTriangle className="w-5 h-5" />
              <span className="font-medium">Kill Switch Engaged - All Trading Stopped</span>
            </div>
          )}

          {status.daily_loss_limit_triggered && !status.kill_switch_engaged && (
            <div className="flex items-center gap-2 p-3 bg-orange-500/20 border border-orange-500 rounded-lg text-orange-400">
              <TrendingDown className="w-5 h-5" />
              <span className="font-medium">Daily Loss Limit Reached</span>
            </div>
          )}

          {status.max_drawdown_triggered && !status.kill_switch_engaged && (
            <div className="flex items-center gap-2 p-3 bg-orange-500/20 border border-orange-500 rounded-lg text-orange-400">
              <TrendingDown className="w-5 h-5" />
              <span className="font-medium">Maximum Drawdown Limit Reached</span>
            </div>
          )}
        </div>
      )}

      {/* Limits Info */}
      <div className="text-sm text-slate-500">
        <div className="grid grid-cols-3 gap-4">
          <div>
            <span className="text-slate-400">Max Position:</span> {(status.portfolio_exposure * 100).toFixed(0)}%
          </div>
          <div>
            <span className="text-slate-400">Max Daily Loss:</span> 5%
          </div>
          <div>
            <span className="text-slate-400">Max Drawdown:</span> 15%
          </div>
        </div>
      </div>
    </div>
  );
}
