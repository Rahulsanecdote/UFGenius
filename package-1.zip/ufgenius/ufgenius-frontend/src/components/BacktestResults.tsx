/**
 * Backtest Results Component
 */
import { TrendingUp, TrendingDown, Activity, Award, Target, AlertCircle } from 'lucide-react';
import { BacktestResult } from '../lib/store';
import { EquityCurveChart, DrawdownChart } from './Charts';

interface BacktestResultsProps {
  result: BacktestResult;
}

export function BacktestResults({ result }: BacktestResultsProps) {
  const formatPercent = (value: number) => `${(value * 100).toFixed(2)}%`;
  const formatCurrency = (value: number) => `$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
          <div className="flex items-center gap-2 text-slate-400 mb-2">
            <TrendingUp className="w-4 h-4" />
            <span className="text-sm">Total Return</span>
          </div>
          <div className={`text-2xl font-bold ${result.total_return >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {formatPercent(result.total_return)}
          </div>
        </div>

        <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
          <div className="flex items-center gap-2 text-slate-400 mb-2">
            <Activity className="w-4 h-4" />
            <span className="text-sm">CAGR</span>
          </div>
          <div className={`text-2xl font-bold ${result.cagr >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {formatPercent(result.cagr)}
          </div>
        </div>

        <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
          <div className="flex items-center gap-2 text-slate-400 mb-2">
            <Award className="w-4 h-4" />
            <span className="text-sm">Sharpe Ratio</span>
          </div>
          <div className="text-2xl font-bold text-white">
            {result.sharpe_ratio?.toFixed(2) || 'N/A'}
          </div>
        </div>

        <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
          <div className="flex items-center gap-2 text-slate-400 mb-2">
            <TrendingDown className="w-4 h-4" />
            <span className="text-sm">Max Drawdown</span>
          </div>
          <div className="text-2xl font-bold text-red-400">
            {formatPercent(result.max_drawdown_percent)}
          </div>
        </div>
      </div>

      {/* Trading Statistics */}
      <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
        <h3 className="text-white font-semibold mb-4">Trading Statistics</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <div className="text-sm text-slate-400">Total Trades</div>
            <div className="text-xl font-bold text-white">{result.total_trades}</div>
          </div>
          <div>
            <div className="text-sm text-slate-400">Win Rate</div>
            <div className="text-xl font-bold text-white">{formatPercent(result.win_rate)}</div>
          </div>
          <div>
            <div className="text-sm text-slate-400">Profit Factor</div>
            <div className="text-xl font-bold text-white">{result.profit_factor.toFixed(2)}</div>
          </div>
          <div>
            <div className="text-sm text-slate-400">Initial / Final Capital</div>
            <div className="text-xl font-bold text-white">
              {formatCurrency(result.initial_capital)} / {formatCurrency(result.final_capital)}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 pt-4 border-t border-slate-700">
          <div>
            <div className="text-sm text-slate-400">Profitable Trades</div>
            <div className="text-xl font-bold text-emerald-400">{result.profitable_trades}</div>
          </div>
          <div>
            <div className="text-sm text-slate-400">Losing Trades</div>
            <div className="text-xl font-bold text-red-400">{result.losing_trades}</div>
          </div>
          <div>
            <div className="text-sm text-slate-400">Average Win</div>
            <div className="text-xl font-bold text-emerald-400">{formatCurrency(result.avg_win)}</div>
          </div>
          <div>
            <div className="text-sm text-slate-400">Average Loss</div>
            <div className="text-xl font-bold text-red-400">{formatCurrency(result.avg_loss)}</div>
          </div>
        </div>
      </div>

      {/* Equity Curve */}
      {result.equity_curve && result.equity_curve.length > 0 && (
        <EquityCurveChart
          data={result.equity_curve.map((point) => ({
            timestamp: point.timestamp,
            close: point.capital,
            capital: point.capital,
            drawdown: point.drawdown_percent || 0,
          }))}
        />
      )}

      {/* Drawdown Chart */}
      {result.equity_curve && result.equity_curve.length > 0 && (
        <DrawdownChart
          data={result.equity_curve.map((point) => ({
            timestamp: point.timestamp,
            close: point.capital,
            capital: point.capital,
            drawdown: point.drawdown_percent || 0,
          }))}
        />
      )}

      {/* Recent Trades */}
      {result.trades && result.trades.length > 0 && (
        <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
          <h3 className="text-white font-semibold mb-4">Recent Trades</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-slate-400 text-sm border-b border-slate-700">
                  <th className="text-left py-2">Entry</th>
                  <th className="text-left py-2">Exit</th>
                  <th className="text-left py-2">Side</th>
                  <th className="text-right py-2">Entry Price</th>
                  <th className="text-right py-2">Exit Price</th>
                  <th className="text-right py-2">P&L</th>
                </tr>
              </thead>
              <tbody>
                {result.trades.slice(0, 10).map((trade: any, index: number) => (
                  <tr key={index} className="border-b border-slate-700/50">
                    <td className="py-2 text-slate-300 text-sm">
                      {new Date(trade.entry_date).toLocaleDateString()}
                    </td>
                    <td className="py-2 text-slate-300 text-sm">
                      {new Date(trade.exit_date).toLocaleDateString()}
                    </td>
                    <td className="py-2">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        trade.side === 'LONG' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {trade.side}
                      </span>
                    </td>
                    <td className="py-2 text-right text-white">{formatCurrency(trade.entry_price)}</td>
                    <td className="py-2 text-right text-white">{formatCurrency(trade.exit_price)}</td>
                    <td className={`py-2 text-right font-medium ${trade.pnl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {formatCurrency(trade.pnl)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div className="flex items-start gap-2 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
        <AlertCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-yellow-200">
          <strong>Past performance does not guarantee future results.</strong> Backtested results may not reflect actual trading results.
          Always paper trade thoroughly before live deployment.
        </div>
      </div>
    </div>
  );
}
