/**
 * Market Data Components
 */
import { TrendingUp, TrendingDown, Activity, RefreshCw } from 'lucide-react';
import { MarketPrice } from '../lib/store';

interface PriceCardProps {
  symbol: string;
  price?: MarketPrice;
  isSelected?: boolean;
  onClick?: () => void;
}

export function PriceCard({ symbol, price, isSelected, onClick }: PriceCardProps) {
  const isPositive = price?.change >= 0;

  return (
    <button
      onClick={onClick}
      className={`w-full p-4 rounded-lg border transition-all ${
        isSelected
          ? 'bg-blue-600/20 border-blue-500'
          : 'bg-slate-800 border-slate-700 hover:border-slate-600'
      }`}
    >
      <div className="flex items-center justify-between mb-2">
        <span className="font-semibold text-white">{symbol}</span>
        {price ? (
          isPositive ? (
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          ) : (
            <TrendingDown className="w-4 h-4 text-red-500" />
          )
        ) : (
          <Activity className="w-4 h-4 text-slate-500" />
        )}
      </div>

      {price ? (
        <>
          <div className="text-xl font-bold text-white mb-1">
            ${price.price.toFixed(2)}
          </div>
          <div className={`text-sm ${isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
            {isPositive ? '+' : ''}
            {price.change.toFixed(2)} ({price.change_percent.toFixed(2)}%)
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Vol: {(price.volume / 1000000).toFixed(1)}M
          </div>
        </>
      ) : (
        <div className="text-slate-500">Loading...</div>
      )}
    </button>
  );
}

interface WatchlistProps {
  symbols: string[];
  prices: Record<string, MarketPrice>;
  selectedSymbol: string;
  onSelect: (symbol: string) => void;
  onRefresh?: () => void;
  isLoading?: boolean;
}

export function Watchlist({ symbols, prices, selectedSymbol, onSelect, onRefresh, isLoading }: WatchlistProps) {
  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700">
      <div className="flex items-center justify-between p-4 border-b border-slate-700">
        <h3 className="text-white font-semibold">Watchlist</h3>
        {onRefresh && (
          <button
            onClick={onRefresh}
            className={`p-1 rounded hover:bg-slate-700 text-slate-400 ${isLoading ? 'animate-spin' : ''}`}
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        )}
      </div>
      <div className="p-2 grid gap-2">
        {symbols.map(symbol => (
          <PriceCard
            key={symbol}
            symbol={symbol}
            price={prices[symbol]}
            isSelected={selectedSymbol === symbol}
            onClick={() => onSelect(symbol)}
          />
        ))}
      </div>
    </div>
  );
}

interface PriceTickerProps {
  symbol: string;
  price?: MarketPrice;
}

export function PriceTicker({ symbol, price }: PriceTickerProps) {
  if (!price) {
    return (
      <div className="flex items-center gap-4">
        <h2 className="text-2xl font-bold text-white">{symbol}</h2>
        <span className="text-slate-500">Loading...</span>
      </div>
    );
  }

  const isPositive = price.change >= 0;

  return (
    <div className="flex items-center gap-4">
      <h2 className="text-2xl font-bold text-white">{symbol}</h2>
      <div className="text-3xl font-bold text-white">${price.price.toFixed(2)}</div>
      <div className={`flex items-center gap-1 ${isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
        {isPositive ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
        <span className="font-semibold">
          {isPositive ? '+' : ''}{price.change.toFixed(2)} ({price.change_percent.toFixed(2)}%)
        </span>
      </div>
    </div>
  );
}
