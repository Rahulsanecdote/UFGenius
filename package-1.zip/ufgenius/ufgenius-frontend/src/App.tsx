/**
 * Universal Financial Genius - Main Application
 * Algorithmic Trading Platform
 */
import { useState, useEffect, useCallback } from 'react';
import './App.css';

// Components
import { Sidebar } from './components/Sidebar';
import { Watchlist, PriceTicker } from './components/MarketData';
import { PriceChart } from './components/Charts';
import { SignalsList } from './components/Signals';
import { BacktestForm } from './components/BacktestForm';
import { BacktestResults } from './components/BacktestResults';
import { RiskStatus } from './components/RiskStatus';

// API
import {
  marketApi,
  strategiesApi,
  backtestApi,
  riskApi,
  signalsApi,
  indicatorsApi
} from './lib/api';

// Types
import {
  MarketPrice,
  Signal,
  Strategy,
  BacktestResult,
  RiskStatus as RiskStatusType
} from './lib/store';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  // Market Data State
  const [selectedSymbol, setSelectedSymbol] = useState('AAPL');
  const [marketPrices, setMarketPrices] = useState<Record<string, MarketPrice>>({});
  const [watchlist] = useState(['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA', 'SPY', 'QQQ']);
  const [historicalData, setHistoricalData] = useState<any[]>([]);

  // Indicators & Signals
  const [indicators, setIndicators] = useState<any>(null);
  const [signals, setSignals] = useState<Signal[]>([]);

  // Strategies
  const [strategies, setStrategies] = useState<Strategy[]>([]);
  const [selectedStrategy, setSelectedStrategy] = useState('rsi_mean_reversion');

  // Backtest
  const [backtestResult, setBacktestResult] = useState<BacktestResult | null>(null);
  const [isBacktesting, setIsBacktesting] = useState(false);

  // Risk
  const [riskStatus, setRiskStatus] = useState<RiskStatusType>({
    kill_switch_engaged: false,
    daily_loss_limit_triggered: false,
    max_drawdown_triggered: false,
    current_capital: 100000,
    peak_capital: 100000,
    daily_pnl: 0,
    daily_pnl_percent: 0,
    drawdown: 0,
    drawdown_percent: 0,
    open_positions: 0,
    portfolio_exposure: 0,
  });

  // Loading states
  const [isLoadingPrices, setIsLoadingPrices] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(false);

  // Load strategies on mount
  useEffect(() => {
    loadStrategies();
    loadRiskStatus();
    loadMarketPrices();
  }, []);

  // Load market data when symbol changes
  useEffect(() => {
    if (selectedSymbol) {
      loadHistoricalData(selectedSymbol);
      loadIndicators(selectedSymbol);
      loadSignals(selectedSymbol);
    }
  }, [selectedSymbol]);

  const loadStrategies = async () => {
    try {
      const response = await strategiesApi.list();
      setStrategies(response.data.strategies);
    } catch (error) {
      console.error('Failed to load strategies:', error);
    }
  };

  const loadRiskStatus = async () => {
    try {
      const response = await riskApi.getStatus();
      setRiskStatus(response.data);
    } catch (error) {
      console.error('Failed to load risk status:', error);
    }
  };

  const loadMarketPrices = async () => {
    setIsLoadingPrices(true);
    try {
      const response = await marketApi.getPrices(watchlist);
      setMarketPrices(response.data.symbols);
    } catch (error) {
      console.error('Failed to load market prices:', error);
    } finally {
      setIsLoadingPrices(false);
    }
  };

  const loadHistoricalData = async (symbol: string) => {
    setIsLoadingData(true);
    try {
      const endDate = new Date().toISOString();
      const startDate = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString();
      const response = await marketApi.getHistory(symbol, startDate, endDate, '1d');
      setHistoricalData(response.data.data);
    } catch (error) {
      console.error('Failed to load historical data:', error);
    } finally {
      setIsLoadingData(false);
    }
  };

  const loadIndicators = async (symbol: string) => {
    try {
      const response = await indicatorsApi.getIndicators(symbol);
      setIndicators(response.data.indicators);
    } catch (error) {
      console.error('Failed to load indicators:', error);
    }
  };

  const loadSignals = async (symbol: string) => {
    try {
      const response = await signalsApi.getSignals(symbol);
      setSignals(response.data.signals);
    } catch (error) {
      console.error('Failed to load signals:', error);
    }
  };

  const handleRunBacktest = async (params: {
    strategy_name: string;
    symbol: string;
    start_date: string;
    end_date: string;
    initial_capital: number;
    commission: number;
    slippage: number;
  }) => {
    setIsBacktesting(true);
    setBacktestResult(null);

    try {
      const response = await backtestApi.run({
        ...params,
        start_date: new Date(params.start_date).toISOString(),
        end_date: new Date(params.end_date).toISOString(),
      });

      if (response.data.status === 'completed') {
        setBacktestResult(response.data.results);
      }
    } catch (error) {
      console.error('Backtest failed:', error);
      alert('Backtest failed. Please check your parameters and try again.');
    } finally {
      setIsBacktesting(false);
    }
  };

  const handleToggleKillSwitch = async (engage: boolean) => {
    try {
      await riskApi.toggleKillSwitch(engage);
      loadRiskStatus();
    } catch (error) {
      console.error('Failed to toggle kill switch:', error);
    }
  };

  const formatChartData = (data: any[]) => {
    return data.map(item => ({
      timestamp: item.timestamp,
      open: item.open,
      high: item.high,
      low: item.low,
      close: item.close,
      volume: item.volume,
    }));
  };

  // Render Dashboard
  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Price Ticker */}
      <div className="flex items-center justify-between">
        <PriceTicker symbol={selectedSymbol} price={marketPrices[selectedSymbol]} />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Watchlist */}
        <div className="lg:col-span-1">
          <Watchlist
            symbols={watchlist}
            prices={marketPrices}
            selectedSymbol={selectedSymbol}
            onSelect={setSelectedSymbol}
            onRefresh={loadMarketPrices}
            isLoading={isLoadingPrices}
          />
        </div>

        {/* Chart */}
        <div className="lg:col-span-2">
          {isLoadingData ? (
            <div className="bg-slate-800 rounded-lg border border-slate-700 p-8 flex items-center justify-center">
              <div className="text-slate-400">Loading chart data...</div>
            </div>
          ) : (
            <PriceChart data={formatChartData(historicalData)} />
          )}
        </div>

        {/* Signals */}
        <div className="lg:col-span-1">
          <SignalsList signals={signals} />
        </div>
      </div>

      {/* Indicators Panel */}
      {indicators && (
        <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
          <h3 className="text-white font-semibold mb-4">Technical Indicators</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {indicators.rsi && (
              <div className="bg-slate-700/50 rounded-lg p-3">
                <div className="text-sm text-slate-400">RSI (14)</div>
                <div className={`text-lg font-bold ${
                  indicators.rsi > 70 ? 'text-red-400' : indicators.rsi < 30 ? 'text-emerald-400' : 'text-white'
                }`}>
                  {indicators.rsi.toFixed(2)}
                </div>
              </div>
            )}
            {indicators.macd && (
              <div className="bg-slate-700/50 rounded-lg p-3">
                <div className="text-sm text-slate-400">MACD</div>
                <div className="text-lg font-bold text-white">
                  {indicators.macd.histogram.toFixed(4)}
                </div>
              </div>
            )}
            {indicators.bollinger_bands && (
              <div className="bg-slate-700/50 rounded-lg p-3">
                <div className="text-sm text-slate-400">BB Position</div>
                <div className="text-lg font-bold text-white">
                  {(indicators.bollinger_bands.position * 100).toFixed(1)}%
                </div>
              </div>
            )}
            {indicators.atr && (
              <div className="bg-slate-700/50 rounded-lg p-3">
                <div className="text-sm text-slate-400">ATR (14)</div>
                <div className="text-lg font-bold text-white">
                  {indicators.atr.toFixed(2)}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Risk Status */}
      <RiskStatus status={riskStatus} onToggleKillSwitch={handleToggleKillSwitch} />
    </div>
  );

  // Render Backtest View
  const renderBacktest = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Configuration */}
        <div className="lg:col-span-1">
          <BacktestForm
            strategies={strategies}
            selectedStrategy={selectedStrategy}
            onStrategyChange={setSelectedStrategy}
            onRunBacktest={handleRunBacktest}
            isRunning={isBacktesting}
          />
        </div>

        {/* Results */}
        <div className="lg:col-span-2">
          {isBacktesting ? (
            <div className="bg-slate-800 rounded-lg border border-slate-700 p-8 flex items-center justify-center">
              <div className="text-slate-400">Running backtest...</div>
            </div>
          ) : backtestResult ? (
            <BacktestResults result={backtestResult} />
          ) : (
            <div className="bg-slate-800 rounded-lg border border-slate-700 p-8 flex items-center justify-center">
              <div className="text-slate-400 text-center">
                Configure parameters and run a backtest to see results
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  // Render Risk View
  const renderRisk = () => (
    <div className="space-y-6">
      <RiskStatus status={riskStatus} onToggleKillSwitch={handleToggleKillSwitch} />
    </div>
  );

  // Render Settings View
  const renderSettings = () => (
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
      <h3 className="text-white font-semibold mb-4">Settings</h3>
      <div className="space-y-4">
        <div>
          <label className="block text-sm text-slate-400 mb-2">API Endpoint</label>
          <input
            type="text"
            defaultValue={import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1'}
            className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white"
            disabled
          />
        </div>
        <div className="pt-4 border-t border-slate-700">
          <h4 className="text-white font-medium mb-2">About</h4>
          <p className="text-slate-400 text-sm">
            Universal Financial Genius v1.0.0 - MVP
          </p>
          <p className="text-slate-500 text-xs mt-2">
            This is a decision-support and automation tool. NOT financial advice.
            All trading involves substantial risk of loss.
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-slate-900">
      {/* Sidebar */}
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <header className="bg-slate-900 border-b border-slate-800 px-6 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-semibold text-white capitalize">
              {activeTab}
            </h1>
            <div className="flex items-center gap-4">
              <span className="text-sm text-slate-400">
                {new Date().toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </span>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="p-6">
          {activeTab === 'dashboard' && renderDashboard()}
          {activeTab === 'backtest' && renderBacktest()}
          {activeTab === 'risk' && renderRisk()}
          {activeTab === 'settings' && renderSettings()}
          {activeTab === 'market' && renderDashboard()}
        </main>
      </div>
    </div>
  );
}

export default App;
