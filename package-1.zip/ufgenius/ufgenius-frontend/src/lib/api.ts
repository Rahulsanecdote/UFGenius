/**
 * API Client for Universal Financial Genius
 */
import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Market Data
export const marketApi = {
  getPrice: (symbol: string) => api.get(`/market/prices/${symbol}`),
  getPrices: (symbols: string[]) => api.get(`/market/prices?symbols=${symbols.join(',')}`),
  getHistory: (symbol: string, startDate?: string, endDate?: string, interval?: string) =>
    api.get(`/market/history/${symbol}`, { params: { start_date: startDate, end_date: endDate, interval } }),
};

// Indicators
export const indicatorsApi = {
  getIndicators: (symbol: string) => api.get(`/indicators/${symbol}`),
};

// Strategies
export const strategiesApi = {
  list: () => api.get('/strategies'),
  getInfo: (strategyName: string) => api.get(`/strategies/${strategyName}`),
};

// Backtest
export const backtestApi = {
  run: (params: {
    strategy_name: string;
    symbol: string;
    start_date: string;
    end_date: string;
    initial_capital?: number;
    commission?: number;
    slippage?: number;
    parameters?: Record<string, any>;
  }) => api.post('/backtest/run', params),
  getResults: (limit?: number) => api.get('/backtest/results', { params: { limit } }),
};

// Risk Management
export const riskApi = {
  getStatus: () => api.get('/risk/status'),
  toggleKillSwitch: (engage: boolean) => api.post('/risk/kill-switch', null, { params: { engage } }),
  resetDaily: () => api.post('/risk/reset-daily'),
};

// Signals
export const signalsApi = {
  getSignals: (symbol: string, strategy?: string) =>
    api.get(`/signals/${symbol}`, { params: { strategy } }),
};

// Watchlist
export const watchlistApi = {
  get: () => api.get('/watchlist'),
  add: (symbol: string, name?: string) => api.post('/watchlist', { symbol, name }),
  remove: (symbol: string) => api.delete(`/watchlist/${symbol}`),
};

// Health
export const healthApi = {
  check: () => api.get('/health'),
};

export default api;
