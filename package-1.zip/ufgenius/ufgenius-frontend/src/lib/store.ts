/**
 * Application State Store
 * Using simple state management for the trading platform
 */
import { useState, useEffect, useCallback } from 'react';

// Types
export interface MarketPrice {
  symbol: string;
  price: number;
  change: number;
  change_percent: number;
  volume: number;
  timestamp: string;
}

export interface Signal {
  symbol: string;
  signal_type: 'BUY' | 'SELL' | 'HOLD';
  strength: number;
  price: number;
  strategy_name: string;
  message: string;
}

export interface IndicatorData {
  rsi?: number;
  macd?: {
    macd: number;
    signal: number;
    histogram: number;
  };
  bollinger_bands?: {
    upper: number;
    middle: number;
    lower: number;
    position: number;
  };
  sma?: Record<string, number>;
  ema?: Record<string, number>;
  atr?: number;
}

export interface BacktestResult {
  strategy_name: string;
  symbol: string;
  initial_capital: number;
  final_capital: number;
  total_return: number;
  cagr: number;
  sharpe_ratio?: number;
  sortino_ratio?: number;
  max_drawdown: number;
  max_drawdown_percent: number;
  total_trades: number;
  profitable_trades: number;
  losing_trades: number;
  win_rate: number;
  profit_factor: number;
  avg_win: number;
  avg_loss: number;
  equity_curve: Array<{ timestamp: string; capital: number; drawdown: number; drawdown_percent?: number }>;
  trades: Array<any>;
}

export interface Strategy {
  name: string;
  description: string;
  parameters: Record<string, any>;
}

export interface RiskStatus {
  kill_switch_engaged: boolean;
  daily_loss_limit_triggered: boolean;
  max_drawdown_triggered: boolean;
  current_capital: number;
  peak_capital: number;
  daily_pnl: number;
  daily_pnl_percent: number;
  drawdown: number;
  drawdown_percent: number;
  open_positions: number;
  portfolio_exposure: number;
}

// Default values
const defaultRiskStatus: RiskStatus = {
  kill_switch_engaged: false,
  daily_loss_limit_triggered: false,
  max_drawdown_triggered: false,
  current_capital: 100000,
  peak_capital: 100000,
  daily_pnl: 0,
  daily_pnl_percent: 0,
  drawdown: 0,
  drawdown_percent: 0,
  open_positions: 0,
  portfolio_exposure: 0,
};

// Store context
interface StoreState {
  // Market data
  selectedSymbol: string;
  marketPrices: Record<string, MarketPrice>;
  watchlist: string[];
  historicalData: any[];

  // Indicators & Signals
  indicators: IndicatorData | null;
  signals: Signal[];

  // Strategies
  strategies: Strategy[];
  selectedStrategy: string;

  // Backtest
  backtestResult: BacktestResult | null;
  isBacktesting: boolean;

  // Risk
  riskStatus: RiskStatus;

  // UI
  isLoading: boolean;
  error: string | null;
}

export function useStore() {
  const [state, setState] = useState<StoreState>({
    selectedSymbol: 'AAPL',
    marketPrices: {},
    watchlist: ['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA', 'SPY', 'QQQ'],
    historicalData: [],
    indicators: null,
    signals: [],
    strategies: [],
    selectedStrategy: 'rsi_mean_reversion',
    backtestResult: null,
    isBacktesting: false,
    riskStatus: defaultRiskStatus,
    isLoading: false,
    error: null,
  });

  // Actions
  const setSelectedSymbol = useCallback((symbol: string) => {
    setState(s => ({ ...s, selectedSymbol: symbol, historicalData: [], indicators: null, signals: [] }));
  }, []);

  const setMarketPrices = useCallback((prices: Record<string, MarketPrice>) => {
    setState(s => ({ ...s, marketPrices: prices }));
  }, []);

  const setHistoricalData = useCallback((data: any[]) => {
    setState(s => ({ ...s, historicalData: data }));
  }, []);

  const setIndicators = useCallback((indicators: IndicatorData | null) => {
    setState(s => ({ ...s, indicators }));
  }, []);

  const setSignals = useCallback((signals: Signal[]) => {
    setState(s => ({ ...s, signals }));
  }, []);

  const setStrategies = useCallback((strategies: Strategy[]) => {
    setState(s => ({ ...s, strategies }));
  }, []);

  const setSelectedStrategy = useCallback((strategy: string) => {
    setState(s => ({ ...s, selectedStrategy: strategy }));
  }, []);

  const setBacktestResult = useCallback((result: BacktestResult | null) => {
    setState(s => ({ ...s, backtestResult: result, isBacktesting: false }));
  }, []);

  const setIsBacktesting = useCallback((isBacktesting: boolean) => {
    setState(s => ({ ...s, isBacktesting }));
  }, []);

  const setRiskStatus = useCallback((riskStatus: RiskStatus) => {
    setState(s => ({ ...s, riskStatus }));
  }, []);

  const setLoading = useCallback((isLoading: boolean) => {
    setState(s => ({ ...s, isLoading }));
  }, []);

  const setError = useCallback((error: string | null) => {
    setState(s => ({ ...s, error }));
  }, []);

  return {
    state,
    actions: {
      setSelectedSymbol,
      setMarketPrices,
      setHistoricalData,
      setIndicators,
      setSignals,
      setStrategies,
      setSelectedStrategy,
      setBacktestResult,
      setIsBacktesting,
      setRiskStatus,
      setLoading,
      setError,
    },
  };
}

export type Store = ReturnType<typeof useStore>;
